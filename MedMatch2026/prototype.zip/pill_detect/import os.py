import os
import sys
from pathlib import Path

print("hello")
def greet(name: str) -> str:
    return f"Hello, {name}!"