// ============================================
// ESP32-CAM Pill Detector Server
// WITH CORS SUPPORT for Cross-Domain Access
// AND OTA UPDATE VIA WEB SERVER
// AND WIFI CONFIGURATION VIA AP MODE
// ============================================

#include <WiFi.h>
#include <WebServer.h>
#include "esp_camera.h"
#include <ArduinoJson.h>
#include <Adafruit_AS7341.h>
#include <Wire.h>
#include <Update.h>  // For OTA updates
#include <HTTPClient.h>
#include <Preferences.h>  // For storing WiFi credentials in flash

// ========== CONFIGURATION ==========
// Default WiFi credentials (can be changed via AP config)
char ssid1[32] = "meshWiFi";
char password1[64] = "Delilah.814";

//char ssid2[32] = "upwork";
//char password2[64] = "upwork786";

char ssid2[32] = "alphatech";
char password2[64] = "alpha8870";

const char* serverUrl = "http://alfalah.suntech2020.com/pill/ip.php";

// OTA Settings
const char* otaUsername = "admin";
const char* otaPassword = "admin123";

// LED Pins
#define LED_PIN 4     // ESP32-CAM onboard LED (GPIO 4)
#define FLASH_PIN 33  // ESP32-CAM flash LED (GPIO 33)

#define I2C_SDA 13  // GPIO14
#define I2C_SCL 2   // GPIO15

Adafruit_AS7341 sensor;

// ========== GLOBALS ==========
WebServer server(80);
Preferences preferences;
bool isLEDOn = false;
bool isFlashOn = false;
bool isAPMode = false;

bool forceAPMode = false;


// Simulated spectrometer data
float baseSpectrum[8] = {415.0, 445.0, 480.0, 515.0, 555.0, 590.0, 630.0, 680.0};
float intensity[8] = {100.0, 150.0, 200.0, 180.0, 160.0, 140.0, 120.0, 100.0};

// Camera configuration
camera_config_t config;

// ========== CORS HEADER FUNCTION ==========
void addCORSHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
}

// ========== BASE64 FUNCTIONS ==========
const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

String base64_encode(uint8_t* buf, size_t bufLen) {
  String result = "";
  int i = 0;
  int j = 0;
  uint8_t char_array_3[3];
  uint8_t char_array_4[4];

  while (bufLen--) {
    char_array_3[i++] = *(buf++);
    if (i == 3) {
      char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
      char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
      char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
      char_array_4[3] = char_array_3[2] & 0x3f;

      for(i = 0; i < 4; i++) {
        result += base64_chars[char_array_4[i]];
      }
      i = 0;
    }
  }

  if (i) {
    for(j = i; j < 3; j++) {
      char_array_3[j] = '\0';
    }

    char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
    char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
    char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
    char_array_4[3] = char_array_3[2] & 0x3f;

    for (j = 0; j < i + 1; j++) {
      result += base64_chars[char_array_4[j]];
    }

    while(i++ < 3) {
      result += '=';
    }
  }

  return result;
}

void setupSpectrometer(){
  Wire.begin(I2C_SDA, I2C_SCL);
  
  // Start sensor with retry
  if (!sensor.begin()) {
    Serial.println("AS7341 not found! Check:");
    Serial.println("1. SDA->GPIO14, SCL->GPIO15");
    Serial.println("2. VIN->3.3V, GND->GND");
  } else {
    Serial.println("ESP32-CAM + AS7341 Ready!");
  }
}

// ========== CAMERA SETUP ==========
void setupCamera() {
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = 5;
  config.pin_d1 = 18;
  config.pin_d2 = 19;
  config.pin_d3 = 21;
  config.pin_d4 = 36;
  config.pin_d5 = 39;
  config.pin_d6 = 34;
  config.pin_d7 = 35;
  config.pin_xclk = 0;
  config.pin_pclk = 22;
  config.pin_vsync = 25;
  config.pin_href = 23;
  config.pin_sscb_sda = 26;
  config.pin_sscb_scl = 27;
  config.pin_pwdn = 32;
  config.pin_reset = -1;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  
  // Adjust based on available memory
  if (psramFound()) {
    config.frame_size = FRAMESIZE_QVGA;  // 320x240
    config.jpeg_quality = 10;           // 0-63, lower = better
    config.fb_count = 2;
    Serial.println("PSRAM OK");
  } else {
    config.frame_size = FRAMESIZE_QVGA;
    config.jpeg_quality = 10;
    config.fb_count = 1;
    Serial.println("PSRAM NOT OK");
  }

  // Initialize camera
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed: 0x%x\n", err);
    return;
  }
  
  Serial.println("Camera OK");
}

// ========== WIFI CREDENTIALS STORAGE ==========
void loadWiFiCredentials() {
  preferences.begin("wifi-config", true);  // Read-only mode
  
  // Check if we should force AP mode
  if (preferences.isKey("force_ap")) {
    forceAPMode = preferences.getBool("force_ap", false);
    if (forceAPMode) {
      Serial.println("Force AP mode flag detected");
    }
  }
  
  if (preferences.isKey("ssid1")) {
    preferences.getString("ssid1", ssid1, sizeof(ssid1));
    preferences.getString("pass1", password1, sizeof(password1));
    Serial.println("Loaded saved WiFi credentials:");
    Serial.printf("SSID1: %s\n", ssid1);
  }
  
  if (preferences.isKey("ssid2")) {
    preferences.getString("ssid2", ssid2, sizeof(ssid2));
    preferences.getString("pass2", password2, sizeof(password2));
    Serial.printf("SSID2: %s\n", ssid2);
  }
  
  preferences.end();
}

void saveWiFiCredentials(String newSsid1, String newPass1, String newSsid2, String newPass2) {
  preferences.begin("wifi-config", false);  // Read-write mode
  
  newSsid1.toCharArray(ssid1, sizeof(ssid1));
  newPass1.toCharArray(password1, sizeof(password1));
  preferences.putString("ssid1", ssid1);
  preferences.putString("pass1", password1);
  
  newSsid2.toCharArray(ssid2, sizeof(ssid2));
  newPass2.toCharArray(password2, sizeof(password2));
  preferences.putString("ssid2", ssid2);
  preferences.putString("pass2", password2);
  
  preferences.end();
  
  Serial.println("WiFi credentials saved to flash!");
  Serial.printf("New SSID1: %s\n", ssid1);
  Serial.printf("New SSID2: %s\n", ssid2);
}

// ========== RESTART IN AP MODE FUNCTION ==========
void restartInAPMode() {
  // Set flag to force AP mode on next boot
  preferences.begin("wifi-config", false);
  preferences.putBool("force_ap", true);
  preferences.end();
  
  // Show restart message
  String html = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Restarting in AP Mode</title>
    <style>
      body { font-family: Arial, sans-serif; text-align: center; margin: 50px; }
      .container { max-width: 500px; margin: 0 auto; padding: 30px; background: #fff3cd; border-radius: 10px; }
      h1 { color: #856404; }
      .info { background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0; }
    </style>
  </head>
  <body>
    <div class="container">
      <h1>🔄 Restarting in AP Mode</h1>
      <div class="info">
        <p><strong>Device will restart in AP mode.</strong></p>
        <p>AP SSID: ESP32-Pill-Detector-XXXX</p>
        <p>Password: 12345678</p>
        <p>Connect to configure WiFi.</p>
      </div>
      <p>Restarting in 5 seconds...</p>
    </div>
  </body>
  </html>
  )rawliteral";
  
  server.send(200, "text/html", html);
  
  // Restart after delay
  delay(5000);
  ESP.restart();
}



// ========== SEND IP TO SERVER FUNCTION ==========
void sendIPToServer(String ipAddress, String network) {
  Serial.println("Sending IP to remote server...");
  
  WiFiClient client;
  HTTPClient http;
  
  // Build the URL with parameters
  String url = serverUrl;
  url += "?ip=" + ipAddress;
  url += "&device=pill_detector";
  url += "&network=" + network;
  url += "&timestamp=" + String(millis());
  
  Serial.print("Request URL: ");
  Serial.println(url);
  
  // Make HTTP GET request
  if (http.begin(client, url)) {
    int httpCode = http.GET();
    
    if (httpCode > 0) {
      Serial.printf("Server response: %d\n", httpCode);
      
      if (httpCode == HTTP_CODE_OK) {
        String payload = http.getString();
        Serial.print("Server reply: ");
        Serial.println(payload);
      }
    } else {
      Serial.printf("HTTP GET failed, error: %s\n", http.errorToString(httpCode).c_str());
    }
    
    http.end();
  } else {
    Serial.println("Unable to connect to server");
  }
  
  Serial.println("IP reporting complete");
}

void startAPMode() {
  Serial.println("\n✗ Both WiFi networks failed! Starting AP mode...");
  
  WiFi.disconnect(true);
  delay(1000);
  WiFi.mode(WIFI_AP);
  
  String apSsid = "ESP32-Pill-Detector-" + String((uint32_t)ESP.getEfuseMac(), HEX);
  WiFi.softAP(apSsid.c_str(), "12345678");
  
  Serial.print("AP SSID: ");
  Serial.println(apSsid);
  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());
  
  digitalWrite(LED_PIN, HIGH);
  isLEDOn = true;
  isAPMode = true;
  
  sendIPToServer(WiFi.softAPIP().toString(), "AP_MODE");
}
// ========== WIFI SETUP FUNCTION ==========
void setupWiFi() {
  loadWiFiCredentials();
  

   if (forceAPMode) {
    Serial.println("Forcing AP mode as requested...");
    forceAPMode = false;  // Reset for next boot
    startAPMode();
    return;
    }

  Serial.println("Attempting WiFi connection...ota 3");
  Serial.printf("Trying SSID1: %s\n", ssid1);
  Serial.printf("Trying SSID2: %s\n", ssid2);
  
  // Try both WiFi networks
  const char* ssids[] = {ssid1, ssid2};
  const char* passwords[] = {password1, password2};
  
  for (int network = 0; network < 2; network++) {
    if (strlen(ssids[network]) == 0) continue;  // Skip empty SSID
    
    Serial.printf("\nTrying network %d: %s\n", network + 1, ssids[network]);
    
    // Clean up previous connection
    WiFi.disconnect(true);
    delay(1000);
    WiFi.mode(WIFI_STA);
    delay(100);
    
    WiFi.begin(ssids[network], passwords[network]);
    
    int attempts = 0;
    while (attempts < 20) {
      if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\n✓ WiFi Connected!");
        Serial.print("SSID: ");
        Serial.println(WiFi.SSID());
        Serial.print("IP Address: ");
        Serial.println(WiFi.localIP());
        
        digitalWrite(LED_PIN, HIGH);
        isLEDOn = true;
        isAPMode = false;
        
        // Send IP to remote server
        sendIPToServer(WiFi.localIP().toString(), WiFi.SSID());
        return;
      }
      
      delay(500);
      Serial.print(".");
      digitalWrite(LED_PIN, !digitalRead(LED_PIN));
      attempts++;
    }
    
    Serial.println("\n✗ Connection failed for this network");
  }
  
  // Both networks failed, start AP mode
  startAPMode();
}



String getSpectrumJSON() {
  DynamicJsonDocument doc(1024);
  doc["status"] = "success";
  doc["simulated"] = false;
  doc["device"] = "AS7341";
  doc["timestamp"] = millis();
  
  // Channels
  JsonArray channels = doc.createNestedArray("channels");
  for (int i = 1; i <= 11; i++) {
    channels.add("CH" + String(i));
  }
  
  // Wavelengths
  float wavelengths[] = {415, 445, 480, 515, 555, 590, 630, 680, 730, 780 , 830};
  JsonArray wavelengthsArr = doc.createNestedArray("wavelengths");
  for (float w : wavelengths) {
    wavelengthsArr.add(w);
  }
  
  uint16_t readings[12];
  
  if (sensor.readAllChannels(readings)) {
    // Print all channels
    Serial.println("Ch1(405nm) Ch2(435nm) Ch3(470nm) Ch4(505nm) Ch5(545nm) Ch6(580nm) Ch7(620nm) Ch8(670nm) Clear NIR Dark");
    
    for(int i=0; i<11; i++) {
      Serial.print(readings[i]);
      Serial.print(" ");
    }
    Serial.println();
  }

  // Values
  JsonArray values = doc.createNestedArray("values");
  for (int i = 0; i < 11; i++) {
    float value = readings[i];
    values.add(value);
  }

  // ALSO include "spectrum" for compatibility
  JsonArray spectrum = doc.createNestedArray("spectrum");
  for (int i = 0; i < 11; i++) {
    spectrum.add(values[i]);
  }
  
  String response;
  serializeJson(doc, response);
  return response;
}

// ========== SYSTEM STATUS ==========
String getSystemStatus() {
  DynamicJsonDocument doc(512);
  doc["status"] = "online";
  doc["ip"] = WiFi.localIP().toString();
  doc["free_heap"] = esp_get_free_heap_size();
  doc["uptime"] = millis();
  doc["led"] = isLEDOn;
  doc["flash"] = isFlashOn;
  doc["spectrometer"] = "AS7341";
  doc["ota_available"] = true;
  doc["ota_endpoint"] = "/ota";
  doc["ap_mode"] = isAPMode;
  
  String response;
  serializeJson(doc, response);
  return response;
}

// ========== WIFI CONFIGURATION PAGE ==========
void handleWiFiConfig() {
  if (!isAPMode) {
    server.send(200, "text/html", "<h1>WiFi Config</h1><p>Device is in STA mode. Switch to AP mode first.</p>");
    return;
  }
  
  String html = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WiFi Configuration - ESP32 Pill Detector</title>
    <style>
      body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
      .container { max-width: 500px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
      h1 { color: #333; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
      .form-group { margin: 15px 0; }
      label { display: block; margin-bottom: 5px; font-weight: bold; }
      input[type="text"], input[type="password"] { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
      .btn { background: #3498db; color: white; border: none; padding: 12px 20px; border-radius: 5px; cursor: pointer; font-size: 16px; width: 100%; }
      .btn:hover { background: #2980b9; }
      .status { padding: 10px; margin: 10px 0; border-radius: 5px; display: none; }
      .success { background: #d4edda; color: #155724; }
      .error { background: #f8d7da; color: #721c24; }
      .info { background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 5px; margin: 10px 0; }
    </style>
    <script>
      function saveWiFi() {
        var ssid1 = document.getElementById('ssid1').value;
        var pass1 = document.getElementById('pass1').value;
        var ssid2 = document.getElementById('ssid2').value;
        var pass2 = document.getElementById('pass2').value;
        
        if (!ssid1 && !ssid2) {
          alert('Please enter at least one WiFi network!');
          return;
        }
        
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/save_wifi', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        xhr.onload = function() {
          var statusDiv = document.getElementById('status');
          statusDiv.style.display = 'block';
          
          if (xhr.status === 200) {
            statusDiv.className = 'status success';
            statusDiv.innerHTML = 'WiFi credentials saved! Device will restart in 5 seconds...';
            setTimeout(function() {
              window.location.href = '/';
            }, 5000);
          } else {
            statusDiv.className = 'status error';
            statusDiv.innerHTML = 'Error: ' + xhr.responseText;
          }
        };
        
        var data = 'ssid1=' + encodeURIComponent(ssid1) + 
                   '&pass1=' + encodeURIComponent(pass1) + 
                   '&ssid2=' + encodeURIComponent(ssid2) + 
                   '&pass2=' + encodeURIComponent(pass2);
        
        xhr.send(data);
      }
      
      function togglePassword(id) {
        var input = document.getElementById(id);
        input.type = input.type === 'password' ? 'text' : 'password';
      }
    </script>
  </head>
  <body>
    <div class="container">
      <h1>🔧 WiFi Configuration</h1>
      
      <div class="info">
        <p><strong>Device is in AP Mode</strong></p>
        <p>Configure WiFi networks for automatic connection.</p>
        <p>Enter at least one network. SSID2 is optional.</p>
      </div>
      
      <div class="form-group">
        <label for="ssid1">Primary WiFi SSID *</label>
        <input type="text" id="ssid1" placeholder="Enter primary WiFi name">
      </div>
      
      <div class="form-group">
        <label for="pass1">Primary WiFi Password *</label>
        <div style="display: flex;">
          <input type="password" id="pass1" placeholder="Enter password" style="flex: 1;">
          <button onclick="togglePassword('pass1')" style="margin-left: 5px;">👁️</button>
        </div>
      </div>
      
      <div class="form-group">
        <label for="ssid2">Secondary WiFi SSID (Optional)</label>
        <input type="text" id="ssid2" placeholder="Enter backup WiFi name">
      </div>
      
      <div class="form-group">
        <label for="pass2">Secondary WiFi Password</label>
        <div style="display: flex;">
          <input type="password" id="pass2" placeholder="Enter password" style="flex: 1;">
          <button onclick="togglePassword('pass2')" style="margin-left: 5px;">👁️</button>
        </div>
      </div>
      
      <button class="btn" onclick="saveWiFi()">💾 Save & Reconnect</button>
      
      <div id="status" class="status"></div>
      
      <hr>
      <p><a href="/">🏠 Back to Home</a> | <a href="/restart">🔄 Restart Device</a></p>
    </div>
  </body>
  </html>
  )rawliteral";
  
  server.send(200, "text/html", html);
}

void handleSaveWiFi() {
  if (server.method() != HTTP_POST) {
    server.send(405, "text/plain", "Method Not Allowed");
    return;
  }
  
  String newSsid1 = server.arg("ssid1");
  String newPass1 = server.arg("pass1");
  String newSsid2 = server.arg("ssid2");
  String newPass2 = server.arg("pass2");
  
  if (newSsid1.length() == 0 && newSsid2.length() == 0) {
    server.send(400, "text/plain", "At least one SSID is required");
    return;
  }
  
  saveWiFiCredentials(newSsid1, newPass1, newSsid2, newPass2);
  
  // Clear force AP flag since we have new credentials
  preferences.begin("wifi-config", false);
  preferences.putBool("force_ap", false);
  preferences.end();
  
  server.send(200, "text/plain", "WiFi credentials saved. Restarting...");
  
  // Restart to try new credentials
  delay(2000);
  ESP.restart();
}

void handleRestart() {
  server.send(200, "text/html", "<h1>Restarting...</h1><p>Device will restart in 3 seconds.</p>");
  delay(3000);
  ESP.restart();
}

// ========== OTA UPDATE FUNCTIONS ==========
void handleOTAPage() {
  // Basic authentication
  if (!server.authenticate(otaUsername, otaPassword)) {
    return server.requestAuthentication();
  }
  
  String html = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>OTA Update - ESP32 Pill Detector</title>
    <style>
      body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
      .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
      h1 { color: #333; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
      .info { background: #e8f4fc; padding: 15px; border-radius: 5px; margin: 20px 0; }
      .warning { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
      input[type="file"] { padding: 10px; margin: 10px 0; }
      input[type="submit"] { background: #3498db; color: white; border: none; padding: 12px 24px; border-radius: 5px; cursor: pointer; font-size: 16px; }
      input[type="submit"]:hover { background: #2980b9; }
      .progress { width: 100%; height: 20px; background: #eee; border-radius: 10px; margin: 20px 0; overflow: hidden; display: none; }
      .progress-bar { height: 100%; background: #3498db; width: 0%; transition: width 0.3s; }
      .status { padding: 10px; margin: 10px 0; border-radius: 5px; }
      .success { background: #d4edda; color: #155724; }
      .error { background: #f8d7da; color: #721c24; }
    </style>
    <script>
      function uploadFirmware() {
        var fileInput = document.getElementById('firmwareFile');
        var file = fileInput.files[0];
        if (!file) {
          alert('Please select a firmware file!');
          return;
        }
        
        if (!file.name.endsWith('.bin')) {
          if (!confirm('File is not a .bin file. Continue anyway?')) {
            return;
          }
        }
        
        var formData = new FormData();
        formData.append('firmware', file);
        
        var progressBar = document.getElementById('progressBar');
        var progressContainer = document.getElementById('progressContainer');
        var statusDiv = document.getElementById('status');
        
        progressContainer.style.display = 'block';
        statusDiv.innerHTML = '';
        
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/ota_update', true);
        
        xhr.upload.onprogress = function(e) {
          if (e.lengthComputable) {
            var percentComplete = (e.loaded / e.total) * 100;
            document.getElementById('progressBar').style.width = percentComplete + '%';
            document.getElementById('progressText').innerHTML = Math.round(percentComplete) + '%';
          }
        };
        
        xhr.onload = function() {
          if (xhr.status === 200) {
            statusDiv.className = 'status success';
            statusDiv.innerHTML = 'Update successful! Device will restart in 3 seconds...';
            setTimeout(function() {
              window.location.href = '/';
            }, 3000);
          } else {
            statusDiv.className = 'status error';
            statusDiv.innerHTML = 'Update failed: ' + xhr.responseText;
          }
          progressContainer.style.display = 'none';
        };
        
        xhr.onerror = function() {
          statusDiv.className = 'status error';
          statusDiv.innerHTML = 'Upload failed. Check connection.';
          progressContainer.style.display = 'none';
        };
        
        xhr.send(formData);
      }
    </script>
  </head>
  <body>
    <div class="container">
      <h1>🔧 OTA Firmware Update</h1>
      
      <div class="info">
        <p><strong>Device:</strong> ESP32 Pill Detector</p>
        <p><strong>IP:</strong> )rawliteral";
  
  html += isAPMode ? WiFi.softAPIP().toString() : WiFi.localIP().toString();
  html += R"rawliteral(</p>
        <p><strong>Current Version:</strong> v1.0</p>
      </div>
      
      <div class="warning">
        <p><strong>⚠️ WARNING:</strong></p>
        <ul>
          <li>Do not power off during update</li>
          <li>Upload only valid .bin files</li>
          <li>Update takes about 30 seconds</li>
          <li>Device will restart automatically</li>
        </ul>
      </div>
      
      <h3>Select Firmware File</h3>
      <input type="file" id="firmwareFile" accept=".bin">
      <br><br>
      <input type="button" value="📤 Upload & Update" onclick="uploadFirmware()">
      
      <div id="progressContainer" class="progress">
        <div id="progressBar" class="progress-bar"></div>
        <div id="progressText" style="text-align:center;margin-top:-20px;"></div>
      </div>
      
      <div id="status" class="status"></div>
      
      <hr>
      <p><a href="/">🏠 Back to Home</a> | <a href="/status">📊 System Status</a></p>
    </div>
  </body>
  </html>
  )rawliteral";
  
  server.send(200, "text/html", html);
}

void handleOTAUpdate() {
  // Basic authentication
  if (!server.authenticate(otaUsername, otaPassword)) {
    return server.requestAuthentication();
  }
  
  HTTPUpload& upload = server.upload();
  
  if (upload.status == UPLOAD_FILE_START) {
    Serial.println("OTA Update Started");
    Serial.printf("Filename: %s\n", upload.filename.c_str());
    
    // Stop camera during update
    esp_camera_deinit();
    
    // Initialize update
    if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
      Update.printError(Serial);
      server.send(500, "text/plain", "OTA begin failed");
      return;
    }
    
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    // Write received data to flash
    if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
      Update.printError(Serial);
      server.send(500, "text/plain", "OTA write failed");
      return;
    }
    
    Serial.printf("Progress: %u bytes\n", upload.totalSize);
    
  } else if (upload.status == UPLOAD_FILE_END) {
    // Finalize update
    if (Update.end(true)) {
      Serial.printf("Update Success: %u bytes\n", upload.totalSize);
      
      // Add a delay before restart
      delay(1000);
      
      server.send(200, "text/plain", "Update successful! Restarting...");
      
      // Restart after a short delay
      delay(2000);
      ESP.restart();
      
    } else {
      Update.printError(Serial);
      server.send(500, "text/plain", "OTA end failed");
    }
    
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    Serial.println("Update aborted");
    Update.abort();
    server.send(500, "text/plain", "Update aborted");
  }
}

// ========== WEB SERVER ROUTES WITH CORS ==========
void setupRoutes() {
  // ========== CORS PREFLIGHT HANDLER (OPTIONS) ==========
  server.onNotFound([]() {
    if (server.method() == HTTP_OPTIONS) {
      addCORSHeaders();
      server.send(200);
    } else {
      server.send(404, "text/plain", "Not Found");
    }
  });

  // Root page
  server.on("/", HTTP_GET, []() {
    addCORSHeaders();
    String html = R"rawliteral(
    <!DOCTYPE html><html>
    <head><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ESP32 Pill Detector</title>
    <style>
      body{font-family:Arial;text-align:center;margin:30px;background:#f5f5f5;}
      .container{max-width:600px;margin:0 auto;background:white;padding:30px;border-radius:15px;box-shadow:0 5px 15px rgba(0,0,0,0.1);}
      h1{color:#3498db;margin-bottom:30px;}
      .btn{display:block;width:100%;padding:15px;margin:10px 0;background:#3498db;color:white;
           border:none;border-radius:8px;font-size:16px;cursor:pointer;text-decoration:none;}
      .btn:hover{background:#2980b9;}
      .status{background:#ecf0f1;padding:15px;border-radius:8px;margin:20px 0;}
      .online{color:green;}
      .offline{color:red;}
      .ota-btn{background:#e74c3c;}
      .ota-btn:hover{background:#c0392b;}
      .wifi-btn{background:#2ecc71;}
      .wifi-btn:hover{background:#27ae60;}
    </style>
    </head>
    <body>
    <div class="container">
      <h1>📷 ESP32 Pill Detector</h1>
      <div class="status">
        <p><strong>IP:</strong> )rawliteral";
  
  if (isAPMode) {
    html += WiFi.softAPIP().toString();
    html += " (AP Mode)";
  } else {
    html += WiFi.localIP().toString();
  }
  
  html += R"rawliteral(</p>
        <p><strong>Status:</strong> <span class=")rawliteral";
  html += isAPMode ? "offline" : "online";
  html += R"rawliteral(">)rawliteral";
  html += isAPMode ? "● AP Mode - Configure WiFi" : "● Online";
  html += R"rawliteral(</span></p>
        <p><strong>Spectrometer:</strong> AS7341</p>
      </div>
      <a href="/stream" class="btn">📹 Live Stream</a>
      <a href="/control" class="btn">🎮 Control Panel</a>
      <a href="/status" class="btn">📊 System Status</a>)rawliteral";
  
  if (isAPMode) {
    html += R"rawliteral(
      <a href="/wifi_config" class="btn wifi-btn">📶 Configure WiFi</a>)rawliteral";
  }
  
  html += R"rawliteral(
      <a href="/ota" class="btn ota-btn">🔧 OTA Update</a>
      <br><br>
      <p><small>Main interface: Connect to PHP server for full features</small></p>
    </div>
    </body></html>
    )rawliteral";
    
    server.send(200, "text/html", html);
  });

  // WiFi Configuration
  server.on("/wifi_config", HTTP_GET, handleWiFiConfig);
  server.on("/save_wifi", HTTP_POST, handleSaveWiFi);
  server.on("/restart", HTTP_GET, handleRestart);
  
  // OTA Update Page
  server.on("/ota", HTTP_GET, handleOTAPage);
  
  // OTA Update Endpoint (handles file upload)
  server.on("/ota_update", HTTP_POST, 
    []() {
      server.send(200, "text/plain", "Update complete!");
    },
    handleOTAUpdate
  );

  // Live video stream
  server.on("/stream", HTTP_GET, []() {
    WiFiClient client = server.client();
    
    String response = "HTTP/1.1 200 OK\r\n";
    response += "Access-Control-Allow-Origin: *\r\n";
    response += "Access-Control-Allow-Methods: GET\r\n";
    response += "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n";
    response += "\r\n";
    server.sendContent(response);

    while (client.connected()) {
      camera_fb_t *fb = esp_camera_fb_get();
      if (!fb) {
        Serial.println("Camera capture failed");
        break;
      }

      String header = "--frame\r\n";
      header += "Content-Type: image/jpeg\r\n";
      header += "Content-Length: " + String(fb->len) + "\r\n\r\n";
      
      server.sendContent(header);
      client.write(fb->buf, fb->len);
      
      esp_camera_fb_return(fb);
      delay(100); // ~10 FPS
      
      if (!client.connected()) break;
    }
  });

  // Capture single image
  server.on("/capture", HTTP_GET, []() {
    addCORSHeaders();
    
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
      server.send(500, "application/json", "{\"error\":\"Camera failed\"}");
      return;
    }

    // Convert to base64 using our function
    String base64Image = base64_encode(fb->buf, fb->len);
    
    DynamicJsonDocument doc(5000);
    doc["status"] = "success";
    doc["image"] = base64Image;
    doc["width"] = fb->width;
    doc["height"] = fb->height;
    doc["size"] = fb->len;
    doc["timestamp"] = millis();
    
    String response;
    serializeJson(doc, response);
    
    server.send(200, "application/json", response);
    esp_camera_fb_return(fb);
  });

  // Get spectrometer data
  server.on("/capture_spectrum", HTTP_GET, []() {
    Serial.println("capture_spectrum called");
    addCORSHeaders();
    server.send(200, "application/json", getSpectrumJSON());
  });

  // Combined scan (image + spectrum)
  server.on("/capture_scan", HTTP_GET, []() {
    addCORSHeaders();
    
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
      server.send(500, "application/json", "{\"error\":\"Camera failed\"}");
      return;
    }

    String base64Image = base64_encode(fb->buf, fb->len);
    
    DynamicJsonDocument doc(6000);
    doc["status"] = "success";
    doc["image"] = base64Image;
    doc["width"] = fb->width;
    doc["height"] = fb->height;
    
    // Add spectrum data
    JsonArray spectrum = doc.createNestedArray("spectrum");
    for (int i = 0; i < 8; i++) {
      spectrum.add(intensity[i] + random(0, 20));
    }
    
    doc["wavelengths"] = "415,445,480,515,555,590,630,680";
    doc["timestamp"] = millis();
    doc["simulated"] = true;
    
    String response;
    serializeJson(doc, response);
    
    server.send(200, "application/json", response);
    esp_camera_fb_return(fb);
  });

  // Toggle LED
  server.on("/toggle_led", HTTP_GET, []() {
    addCORSHeaders();
    
    isLEDOn = !isLEDOn;
    digitalWrite(LED_PIN, isLEDOn ? HIGH : LOW);
    
    DynamicJsonDocument doc(200);
    doc["status"] = "success";
    doc["led_on"] = isLEDOn;
    doc["pin"] = LED_PIN;
    
    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
  });

  // Toggle LED - OPTIONS (CORS preflight)
  server.on("/toggle_led", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });

  // Toggle Flash
  server.on("/toggle_flash", HTTP_GET, []() {
    addCORSHeaders();
    
    isFlashOn = !isFlashOn;
    digitalWrite(FLASH_PIN, isFlashOn ? HIGH : LOW);
    
    DynamicJsonDocument doc(200);
    doc["status"] = "success";
    doc["flash_on"] = isFlashOn;
    doc["pin"] = FLASH_PIN;
    
    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
  });

  // Toggle Flash - OPTIONS (CORS preflight)
  server.on("/toggle_flash", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });

  // System status
  server.on("/status", HTTP_GET, []() {
    addCORSHeaders();
    server.send(200, "application/json", getSystemStatus());
  });

  // Control panel
  server.on("/control", HTTP_GET, []() {
    addCORSHeaders();
    
    String ledColor = isLEDOn ? "#e74c3c" : "#2ecc71";
    String flashColor = isFlashOn ? "#e74c3c" : "#f39c12";
    
    String html = R"rawliteral(
    <!DOCTYPE html><html>
    <head><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Control Panel</title>
    <style>
      body{font-family:Arial;text-align:center;margin:20px;}
      .btn{padding:15px 30px;margin:10px;font-size:16px;border:none;border-radius:8px;cursor:pointer;color:white;}
      .info{background:#3498db;}
      .led{background:)rawliteral";
    html += ledColor;
    html += R"rawliteral(;}
      .flash{background:)rawliteral";
    html += flashColor;
    html += R"rawliteral(;}
      .cam{background:#9b59b6;}
      .ota{background:#e74c3c;}
      .wifi{background:#2ecc71;}
    </style>
    <script>
      async function toggle(device){
        const response = await fetch('/toggle_'+device);
        const data = await response.json();
        location.reload();
      }
      async function capture(type){
        const response = await fetch('/capture_' + type);
        const data = await response.json();
        alert(type.charAt(0).toUpperCase() + type.slice(1) + ' captured!');
      }
    </script>
    </head>
    <body>
    <h1>Control Panel</h1>
    <p><strong>IP:</strong> )rawliteral";
    html += isAPMode ? WiFi.softAPIP().toString() : WiFi.localIP().toString();
    html += R"rawliteral(</p>
    <button class="btn led" onclick="toggle('led')">)rawliteral";
    html += isLEDOn ? "🔴 TURN LED OFF" : "🟢 TURN LED ON";
    html += R"rawliteral(</button><br>
    <button class="btn flash" onclick="toggle('flash')">)rawliteral";
    html += isFlashOn ? "🔴 TURN FLASH OFF" : "💡 TURN FLASH ON";
    html += R"rawliteral(</button><br>
    <button class="btn cam" onclick="capture('image')">📸 Capture Image</button><br>
    <button class="btn info" onclick="capture('spectrum')">🌈 Capture Spectrum</button><br>
    <button class="btn cam" onclick="capture('scan')">🔍 Full Scan</button><br>)rawliteral";
    
    if (isAPMode) {
      html += R"rawliteral(
      <button class="btn wifi" onclick="window.location.href='/wifi_config'">📶 Configure WiFi</button><br>)rawliteral";
    }
    
    if (!isAPMode) {
      html += R"rawliteral(
      <button class="btn" style="background:#f39c12;" onclick="window.location.href='/restart_in_ap_mode'">🔄 Restart in AP Mode</button><br>)rawliteral";
    }
    html += R"rawliteral(
    <button class="btn ota" onclick="window.location.href='/ota'">🔧 OTA Update</button><br>
    <hr>
    <p><a href="/stream">📹 Live Stream</a> | <a href="/">🏠 Home</a></p>
    </body></html>
    )rawliteral";
    
    server.send(200, "text/html", html);
  });

  // ========== CATCH-ALL OPTIONS HANDLER ==========
  server.on("/capture", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/capture_spectrum", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/capture_scan", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/status", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/ota", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/wifi_config", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/save_wifi", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });
  
  server.on("/restart", HTTP_OPTIONS, []() {
    addCORSHeaders();
    server.send(200);
  });

  server.on("/restart_in_ap_mode", HTTP_GET, []() {
    addCORSHeaders();
    restartInAPMode();
  });
  server.begin();
  Serial.println("HTTP server with OTA and WiFi config started!");
}

// ========== SETUP ==========
void setup() {
  delay(500);  // Let ESP32 boot first
  Serial.begin(115200);
  Serial.println("\n=== ESP32-CAM Pill Detector with WiFi Config ===\n");
  
  // Setup pins
  pinMode(LED_PIN, OUTPUT);
  pinMode(FLASH_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  digitalWrite(FLASH_PIN, LOW);

  // Initialize components
  setupCamera();
  setupWiFi();  // This now loads saved credentials and connects
  setupRoutes();
  setupSpectrometer();

  Serial.println("\n=== SYSTEM READY ===");
  Serial.println("Available endpoints:");
  Serial.println("  /                - Home page");
  if (isAPMode) {
    Serial.println("  /wifi_config     - Configure WiFi (AP Mode)");
  }
  Serial.println("  /ota             - OTA Update page");
  Serial.println("  /stream          - Live video stream");
  Serial.println("  /capture         - Capture single image");
  Serial.println("  /capture_spectrum- Get spectrometer data");
  Serial.println("  /capture_scan    - Image + spectrum");
  Serial.println("  /toggle_led      - Toggle onboard LED");
  Serial.println("  /toggle_flash    - Toggle flash LED");
  Serial.println("  /status          - System status");
  Serial.println("  /control         - Control panel");
  Serial.println("  /restart         - Restart device");
  Serial.println("\nOTA Credentials: " + String(otaUsername) + " / " + String(otaPassword));
}

// ========== MAIN LOOP ==========
void loop() {
  server.handleClient();
  
  // Heartbeat blink - different pattern in AP mode
  static unsigned long lastBlink = 0;
  if (millis() - lastBlink > (isAPMode ? 1000 : 3000)) {
    lastBlink = millis();
    if (isAPMode) {
      digitalWrite(LED_PIN, !digitalRead(LED_PIN));  // Blink in AP mode
    } else if (WiFi.status() == WL_CONNECTED) {
      digitalWrite(LED_PIN, HIGH);  // Solid when connected
    }
  }
}