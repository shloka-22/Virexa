<?php
// Server configuration for your specific directory
$curr_ip=trim(file_get_contents("ip.txt"));
define('ESP32_IP', $curr_ip);  // Change to your ESP32 IP
define('ESP32_PORT', '80');

// Use absolute paths for your directory
$base_dir = '/home/aftab/web/alfalah.suntech2020.com/public_html/pill';
define('BASE_DIR', $base_dir);
define('DATA_DIR', $base_dir . '/data/');
define('UPLOAD_DIR', DATA_DIR . 'uploads/');

// Database files
define('PILLS_DB', DATA_DIR . 'pills.json');
define('SCANS_DB', DATA_DIR . 'scans.json');

// Website URL (for JavaScript)
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$domain = $_SERVER['HTTP_HOST'];
define('SITE_URL', $protocol . '://' . $domain . '/pill/');

// Create directories if they don't exist
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0777, true);
    chmod(DATA_DIR, 0777);
}
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0777, true);
    chmod(UPLOAD_DIR, 0777);
}

// Initialize database files
function init_database() {
    if (!file_exists(PILLS_DB)) {
        file_put_contents(PILLS_DB, json_encode(['pills' => []], JSON_PRETTY_PRINT));
        chmod(PILLS_DB, 0666);
    }
    if (!file_exists(SCANS_DB)) {
        file_put_contents(SCANS_DB, json_encode(['scans' => []], JSON_PRETTY_PRINT));
        chmod(SCANS_DB, 0666);
    }
}

// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Initialize
init_database();

// Error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>