<?php
require_once 'config.php';
header('Content-Type: application/javascript');
?>
// JavaScript Configuration
const ESP_IP = '<?php echo ESP32_IP; ?>';
const SERVER_BASE = '<?php echo SITE_URL; ?>';
const API_URL = SERVER_BASE + 'api/';