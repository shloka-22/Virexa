<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Save New Pill - Alfalah Suntech</title>
    <style>
        :root {
            --primary: #3498db;
            --success: #2ecc71;
            --danger: #e74c3c;
            --dark: #2c3e50;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .mobile-container {
            max-width: 100%;
            margin: 0 auto;
            padding: 15px;
            background: white;
            min-height: 100vh;
            border-radius: 0;
        }
        
        .header {
            text-align: center;
            padding: 20px 0;
            background: linear-gradient(135deg, var(--primary), var(--dark));
            color: white;
            margin: -15px -15px 20px -15px;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .header p {
            margin: 5px 0 0;
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .nav-tabs {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
            background: white;
            border-radius: 15px;
            padding: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nav-tab {
            flex: 1;
            text-align: center;
            padding: 12px 0;
            text-decoration: none;
            color: #666;
            font-weight: 500;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .nav-tab.active {
            background: var(--success);
            color: white;
        }
        
        .nav-tab i {
            display: block;
            font-size: 1.2rem;
            margin-bottom: 5px;
        }
        
        .form-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border: 1px solid #eee;
        }
        
        .form-title {
            font-size: 1.1rem;
            color: var(--dark);
            margin: 0 0 20px 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .required::after {
            content: " *";
            color: var(--danger);
        }
        
        .btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn:active {
            transform: scale(0.98);
        }
        
        .btn-capture {
            background: linear-gradient(135deg, var(--primary), #2980b9);
            color: white;
        }
        
        .btn-save {
            background: linear-gradient(135deg, var(--success), #27ae60);
            color: white;
        }
        
        .btn-cancel {
            background: linear-gradient(135deg, #95a5a6, #7f8c8d);
            color: white;
        }
        
        .status-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin: 20px 0;
            text-align: center;
        }
        
        .status-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .status-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .status-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        
        .spinner {
            display: none;
            width: 30px;
            height: 30px;
            border: 3px solid rgba(52, 152, 219, 0.3);
            border-radius: 50%;
            border-top-color: var(--primary);
            animation: spin 1s ease-in-out infinite;
            margin: 0 auto 15px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .connection-status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .status-dot.online {
            background: var(--success);
        }
        
        .status-dot.offline {
            background: var(--danger);
        }
        
        .spectrum-preview {
            background: #1a1a1a;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
            color: white;
            font-family: monospace;
            font-size: 0.85rem;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .channel-row {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr 2fr;
            gap: 10px;
            margin-bottom: 5px;
            padding-bottom: 5px;
            border-bottom: 1px solid #333;
            align-items: center;
        }
        
        .progress-bar {
            height: 8px;
            background: #333;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #3498db, #2ecc71);
            border-radius: 4px;
        }
        
        .channel-count {
            text-align: center;
            padding: 10px;
            background: rgba(255,255,255,0.1);
            border-radius: 5px;
            margin-top: 10px;
        }
        
        @media (max-width: 480px) {
            .channel-row {
                grid-template-columns: 1fr 1fr;
                gap: 5px;
            }
            
            .progress-bar {
                grid-column: 1 / -1;
            }
        }
    </style>
</head>
<body>
    <div class="mobile-container">
        <!-- Header -->
        <div class="header">
            <h1>💊 Save New Pill</h1>
            <p>Alfalah Suntech - Database Manager</p>
        </div>
        
        <!-- Navigation Tabs -->
        <div class="nav-tabs">
            <a href="index.php" class="nav-tab">
                <i>🔍</i>
                Scan Pill
            </a>
            <a href="save_pill.php" class="nav-tab active">
                <i>➕</i>
                Save New
            </a>
        </div>
        
        <!-- Connection Status -->
        <div class="connection-status">
            <div style="display: flex; align-items: center;">
                <div id="connDot" class="status-dot offline"></div>
                <div>
                    <div style="font-weight: 600;">ESP32</div>
                    <div style="font-size: 0.85rem; color: #666;"><?php echo ESP32_IP; ?></div>
                </div>
            </div>
            <div style="display: flex; gap: 10px;">
                <button onclick="testConnection()" style="padding: 8px 15px; background: var(--primary); color: white; border: none; border-radius: 5px; font-size: 0.85rem;">
                    Test
                </button>
                <button onclick="toggleLED()" style="padding: 8px 15px; background: var(--warning); color: white; border: none; border-radius: 5px; font-size: 0.85rem;">
                    LED
                </button>
            </div>
        </div>
        
        <!-- Status Messages -->
        <div id="statusBox" class="status-box" style="display: none;"></div>
        
        <!-- Main Form -->
        <div class="form-card">
            <h2 class="form-title">
                <i>📝</i> Pill Information
            </h2>
            
            <div class="form-group">
                <label class="form-label required">Pill Name</label>
                <input type="text" id="pillName" class="form-control" 
                       placeholder="e.g., Paracetamol 500mg" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Manufacturer</label>
                <input type="text" id="manufacturer" class="form-control" 
                       placeholder="e.g., PharmaCorp Inc.">
            </div>
            
            <div class="form-group">
                <label class="form-label">Expiry Date</label>
                <input type="date" id="expiryDate" class="form-control">
            </div>
            
            <div class="form-group">
                <label class="form-label">Notes</label>
                <textarea id="notes" class="form-control" rows="3" 
                          placeholder="Additional information about this pill..."></textarea>
            </div>
            
            <!-- Spectrum Data Preview -->
            <div id="spectrumPreview" class="spectrum-preview" style="display: none;">
                <h4 style="margin-top: 0; color: #ccc;">📊 Captured Spectrum (11 Channels)</h4>
                <div id="spectrumData"></div>
            </div>
            
            <!-- Capture Button -->
            <button onclick="captureSpectrum()" class="btn btn-capture" id="captureBtn">
                <i>📸</i> Capture Spectrum Signature
            </button>
            
            <!-- Save Button (initially disabled) -->
            <button onclick="savePill()" class="btn btn-save" id="saveBtn" disabled>
                <i>💾</i> Save to Database
            </button>
            
            <!-- Cancel Button -->
            <button onclick="window.location.href='index.php'" class="btn btn-cancel">
                <i>↩️</i> Back to Scanner
            </button>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script>
        // Configuration
        const ESP_IP = '<?php echo ESP32_IP; ?>';
        const API_URL = '<?php echo SITE_URL; ?>api/';
        
        // 11-channel wavelength configuration
        const WAVELENGTHS = [415, 445, 480, 515, 555, 590, 630, 680, 720, 760, 850];
        
        // State variables
        let capturedSpectrum = null;
        
        // DOM elements
        const statusBox = document.getElementById('statusBox');
        const spectrumPreview = document.getElementById('spectrumPreview');
        const spectrumData = document.getElementById('spectrumData');
        const captureBtn = document.getElementById('captureBtn');
        const saveBtn = document.getElementById('saveBtn');
        const connDot = document.getElementById('connDot');
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            testConnection();
        });
        
        // Show status message
        function showStatus(message, type = 'info') {
            statusBox.style.display = 'block';
            statusBox.className = `status-box status-${type}`;
            statusBox.innerHTML = message;
            
            // Auto-hide success messages after 5 seconds
            if (type === 'success') {
                setTimeout(() => {
                    statusBox.style.display = 'none';
                }, 5000);
            }
        }
        
        // Capture Spectrum
        async function captureSpectrum() {
            // Show loading
            captureBtn.innerHTML = '<div class="spinner" style="display: inline-block; width: 20px; height: 20px; margin-right: 10px;"></div> Capturing...';
            captureBtn.disabled = true;
            showStatus('📸 Capturing spectrum data from ESP32...', 'info');
            
            try {
                // Call ESP32 spectrum endpoint
                const response = await fetch(`http://${ESP_IP}/capture_spectrum`);
                
                if (!response.ok) {
                    throw new Error(`ESP32 error: ${response.status}`);
                }
                
                const data = await response.json();
                
                // Validate data
                const spectrumValues = data.spectrum || data.values || [];
                if (!Array.isArray(spectrumValues) || spectrumValues.length === 0) {
                    throw new Error('No valid spectrum data received');
                }
                
                // Check if we have 11 channels
                if (spectrumValues.length !== 11) {
                    console.warn(`Expected 11 channels, got ${spectrumValues.length}`);
                }
                
                // Store captured data
                capturedSpectrum = {
                    timestamp: new Date().toISOString(),
                    spectrum: spectrumValues,
                    wavelengths: data.wavelengths || WAVELENGTHS,
                    simulated: data.simulated || false,
                    device: data.device || 'ESP32'
                };
                
                // Display spectrum data
                displaySpectrumData(spectrumValues);
                
                // Enable save button
                saveBtn.disabled = false;
                
                showStatus(`✅ Spectrum captured successfully! (${spectrumValues.length} channels)`, 'success');
                
            } catch (error) {
                console.error('Capture failed:', error);
                showStatus(`❌ Capture failed: ${error.message}`, 'error');
                capturedSpectrum = null;
                saveBtn.disabled = true;
                spectrumPreview.style.display = 'none';
            } finally {
                captureBtn.innerHTML = '<i>📸</i> Capture Spectrum Signature';
                captureBtn.disabled = false;
            }
        }
        
        // Display spectrum data
        function displaySpectrumData(spectrum) {
            spectrumPreview.style.display = 'block';
            spectrumData.innerHTML = '';
            
            // Show channel count
            const countDiv = document.createElement('div');
            countDiv.className = 'channel-count';
            countDiv.textContent = `11 Spectral Channels Captured`;
            spectrumData.appendChild(countDiv);
            
            spectrum.forEach((value, index) => {
                const wavelength = WAVELENGTHS[index] || `CH${index + 1}`;
                const percentage = Math.min(100, ((value / 4095) * 100).toFixed(1));
                
                const row = document.createElement('div');
                row.className = 'channel-row';
                row.innerHTML = `
                    <span style="color: #ccc;">${wavelength}nm</span>
                    <span style="text-align: right;">${value.toFixed(1)}</span>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${percentage}%"></div>
                    </div>
                    <span style="text-align: right; color: #2ecc71;">${percentage}%</span>
                `;
                spectrumData.appendChild(row);
            });
            
            // Add summary
            const validValues = spectrum.filter(v => v > 0);
            if (validValues.length > 0) {
                const max = Math.max(...validValues).toFixed(1);
                const min = Math.min(...validValues).toFixed(1);
                const avg = (validValues.reduce((a, b) => a + b, 0) / validValues.length).toFixed(1);
                
                const summary = document.createElement('div');
                summary.style.marginTop = '15px';
                summary.style.paddingTop = '10px';
                summary.style.borderTop = '2px solid #333';
                summary.innerHTML = `
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; text-align: center;">
                        <div>
                            <div style="color: #aaa; font-size: 0.8rem;">Max</div>
                            <div style="color: #ff6b6b; font-weight: bold;">${max}</div>
                        </div>
                        <div>
                            <div style="color: #aaa; font-size: 0.8rem;">Min</div>
                            <div style="color: #4ecdc4; font-weight: bold;">${min}</div>
                        </div>
                        <div>
                            <div style="color: #aaa; font-size: 0.8rem;">Avg</div>
                            <div style="color: #ffe66d; font-weight: bold;">${avg}</div>
                        </div>
                    </div>
                `;
                spectrumData.appendChild(summary);
            }
        }
        
        // Save Pill to Database
        async function savePill() {
            // Validate inputs
            const pillName = document.getElementById('pillName').value.trim();
            if (!pillName) {
                showStatus('❌ Please enter a pill name', 'error');
                return;
            }
            
            if (!capturedSpectrum) {
                showStatus('❌ Please capture spectrum data first', 'error');
                return;
            }
            
            // Show loading
            saveBtn.innerHTML = '<div class="spinner" style="display: inline-block; width: 20px; height: 20px; margin-right: 10px;"></div> Saving...';
            saveBtn.disabled = true;
            
            try {
                // Prepare data
                const pillData = {
                    name: pillName,
                    manufacturer: document.getElementById('manufacturer').value.trim() || '',
                    expiry: document.getElementById('expiryDate').value || '',
                    notes: document.getElementById('notes').value.trim() || '',
                    spectrum: capturedSpectrum.spectrum,
                    wavelengths: capturedSpectrum.wavelengths,
                    timestamp: capturedSpectrum.timestamp,
                    channel_count: capturedSpectrum.spectrum.length
                };
                
                // Send to server
                const response = await fetch(API_URL + 'save_pill.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(pillData)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showStatus(`✅ Pill "${pillName}" saved successfully! (ID: ${result.pill_id})`, 'success');
                    
                    // Reset form
                    document.getElementById('pillName').value = '';
                    document.getElementById('manufacturer').value = '';
                    document.getElementById('expiryDate').value = '';
                    document.getElementById('notes').value = '';
                    capturedSpectrum = null;
                    spectrumPreview.style.display = 'none';
                    saveBtn.disabled = true;
                    
                    // Auto-redirect after 3 seconds
                    setTimeout(() => {
                        window.location.href = 'index.php';
                    }, 3000);
                    
                } else {
                    throw new Error(result.error || 'Unknown error');
                }
                
            } catch (error) {
                console.error('Save failed:', error);
                showStatus(`❌ Failed to save pill: ${error.message}`, 'error');
            } finally {
                saveBtn.innerHTML = '<i>💾</i> Save to Database';
                saveBtn.disabled = false;
            }
        }
        
        // Toggle LED
        async function toggleLED() {
            try {
                const response = await fetch(`http://${ESP_IP}/toggle_led`);
                const data = await response.json();
                
                showStatus(`💡 LED turned ${data.led_on ? 'ON' : 'OFF'}`, 'info');
                
            } catch (error) {
                console.error('LED toggle failed:', error);
                showStatus('❌ LED control failed', 'error');
            }
        }
        
        // Test Connection
        async function testConnection() {
            try {
                const response = await fetch(`http://${ESP_IP}/`, {
                    mode: 'no-cors',
                    cache: 'no-store'
                });
                
                updateConnectionStatus(true);
                showStatus('✅ Connected to ESP32', 'success');
                
            } catch (error) {
                updateConnectionStatus(false);
                showStatus('❌ ESP32 connection failed', 'error');
            }
        }
        
        function updateConnectionStatus(isConnected) {
            if (isConnected) {
                connDot.className = 'status-dot online';
            } else {
                connDot.className = 'status-dot offline';
            }
        }
    </script>
</body>
</html>