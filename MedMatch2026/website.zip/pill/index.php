<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Pill Scanner - Alfalah Suntech</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>css/styles.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>css/mobile.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #3498db;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --dark: #2c3e50;
            --light: #ecf0f1;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .mobile-container {
            max-width: 100%;
            margin: 0 auto;
            padding: 15px;
            background: white;
            min-height: 100vh;
            border-radius: 0;
        }
        
        .header {
            text-align: center;
            padding: 20px 0;
            background: linear-gradient(135deg, var(--primary), var(--dark));
            color: white;
            margin: -15px -15px 20px -15px;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .header p {
            margin: 5px 0 0;
            opacity: 0.9;
            font-size: 0.9rem;
        }
        
        .nav-tabs {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
            background: white;
            border-radius: 15px;
            padding: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .nav-tab {
            flex: 1;
            text-align: center;
            padding: 12px 0;
            text-decoration: none;
            color: #666;
            font-weight: 500;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .nav-tab.active {
            background: var(--primary);
            color: white;
        }
        
        .nav-tab i {
            display: block;
            font-size: 1.2rem;
            margin-bottom: 5px;
        }
        
        .card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            border: 1px solid #eee;
        }
        
        .card-title {
            font-size: 1.1rem;
            color: var(--dark);
            margin: 0 0 15px 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .camera-container {
            width: 100%;
            height: 280px;
            background: #1a1a1a;
            border-radius: 12px;
            overflow: hidden;
            position: relative;
            margin-bottom: 15px;
        }
        
        .camera-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #666;
        }
        
        .camera-placeholder i {
            font-size: 3rem;
            margin-bottom: 10px;
        }
        
        #liveStream {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .control-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin: 20px 0;
        }
        
        .btn {
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn:active {
            transform: scale(0.98);
        }
        
        .btn-scan {
            background: linear-gradient(135deg, var(--success), #27ae60);
            color: white;
            grid-column: 1 / -1;
        }
        
        .btn-led {
            background: linear-gradient(135deg, var(--warning), #e67e22);
            color: white;
        }
        
        .btn-test {
            background: linear-gradient(135deg, #9b59b6, #8e44ad);
            color: white;
        }
        
        .status-display {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            margin-bottom: 15px;
        }
        
        .status-icon {
            font-size: 3rem;
            margin-bottom: 10px;
        }
        
        .status-text {
            font-size: 1.2rem;
            font-weight: 600;
            margin: 10px 0;
        }
        
        .confidence-text {
            color: #666;
            font-size: 0.9rem;
        }
        
        .result-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .result-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }
        
        .result-label {
            font-size: 0.85rem;
            color: #666;
            margin-bottom: 5px;
        }
        
        .result-value {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--dark);
        }
        
        .connection-status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
        }
        
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .status-dot.online {
            background: var(--success);
        }
        
        .status-dot.offline {
            background: var(--danger);
        }
        
        .spinner {
            display: none;
            width: 30px;
            height: 30px;
            border: 3px solid rgba(52, 152, 219, 0.3);
            border-radius: 50%;
            border-top-color: var(--primary);
            animation: spin 1s ease-in-out infinite;
            margin: 0 auto 15px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Spectrum chart container */
        .spectrum-container {
            height: 250px;
            margin: 15px 0;
        }
        
        @media (max-width: 480px) {
            .control-buttons {
                grid-template-columns: 1fr;
            }
            
            .result-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="mobile-container">
        <!-- Header -->
        <div class="header">
            <h1>💊 Pill Authenticator</h1>
            <p>Alfalah Suntech - Mobile Scanner</p>
        </div>
        
        <!-- Navigation Tabs -->
        <div class="nav-tabs">
            <a href="index.php" class="nav-tab active">
                <i>🔍</i>
                Scan Pill
            </a>
            <a href="save_pill.php" class="nav-tab">
                <i>➕</i>
                Save New
            </a>
        </div>
        
        <!-- Camera Section -->
        <div class="card">
            <h2 class="card-title">
                <i>📷</i> Camera Stream
            </h2>
            <div class="camera-container">
                <div id="streamPlaceholder" class="camera-placeholder">
                    <i>📷</i>
                    <p>Stream not started</p>
                </div>
                <img id="liveStream" style="display: none;" alt="Live Stream">
            </div>
            
            <!-- Stream Controls -->
            <div style="display: flex; gap: 10px; margin-top: 15px;">
                <button onclick="startStream()" class="btn" style="flex: 1; background: var(--primary); color: white;">
                    ▶️ Start Stream
                </button>
                <button onclick="stopStream()" class="btn" style="flex: 1; background: #666; color: white; display: none;">
                    ⏸️ Stop
                </button>
            </div>
        </div>
        
        <!-- Spectrum Chart -->
        <div class="card" style="display: none;" id="spectrumCard">
            <h2 class="card-title">
                <i>📈</i> Spectrum Analysis
            </h2>
            <div class="spectrum-container">
                <canvas id="spectrumChart"></canvas>
            </div>
        </div>
        
        <!-- Control Buttons -->
        <div class="control-buttons">
            <button onclick="startScan()" class="btn btn-scan" id="scanBtn">
                <i>🔍</i> Scan Pill
            </button>
            <button onclick="toggleLED()" class="btn btn-led">
                <i>💡</i> LED
            </button>
            <button onclick="testConnection()" class="btn btn-test">
                <i>🔌</i> Test
            </button>
        </div>
        
        <!-- Status Display -->
        <div class="status-display">
            <div class="spinner" id="scanSpinner"></div>
            <div id="statusIcon" class="status-icon">🔍</div>
            <div id="statusText" class="status-text">Ready to Scan</div>
            <div id="confidenceText" class="confidence-text"></div>
        </div>
        
        <!-- Results Grid -->
        <div class="card">
            <h2 class="card-title">
                <i>📊</i> Scan Results
            </h2>
            <div class="result-grid">
                <div class="result-item">
                    <div class="result-label">Pill Name</div>
                    <div id="pillName" class="result-value">-</div>
                </div>
                <div class="result-item">
                    <div class="result-label">Match Score</div>
                    <div id="matchScore" class="result-value">-</div>
                </div>
                <div class="result-item">
                    <div class="result-label">Status</div>
                    <div id="pillStatus" class="result-value">-</div>
                </div>
                <div class="result-item">
                    <div class="result-label">LED</div>
                    <div id="ledStatus" class="result-value" style="color: var(--danger);">OFF</div>
                </div>
            </div>
        </div>
        
        <!-- Connection Status -->
        <div class="connection-status">
            <div style="display: flex; align-items: center;">
                <div id="connDot" class="status-dot offline"></div>
                <div>
                    <div style="font-weight: 600;">ESP32</div>
                    <div style="font-size: 0.85rem; color: #666;"><?php echo ESP32_IP; ?></div>
                </div>
            </div>
            <div id="lastUpdate" style="color: #666; font-size: 0.85rem;">
                Last: -
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script>
        // Configuration
        const ESP_IP = '<?php echo ESP32_IP; ?>';
        const API_URL = '<?php echo SITE_URL; ?>api/';
        
        // 11-channel wavelength configuration (update these based on your spectrometer)
        const WAVELENGTHS = [415, 445, 480, 515, 555, 590, 630, 680, 720, 760, 850];
        
        // State variables
        let isStreamActive = false;
        let streamInterval = null;
        let chartInstance = null;
        
        // DOM elements
        const liveStream = document.getElementById('liveStream');
        const streamPlaceholder = document.getElementById('streamPlaceholder');
        const scanSpinner = document.getElementById('scanSpinner');
        const statusIcon = document.getElementById('statusIcon');
        const statusText = document.getElementById('statusText');
        const confidenceText = document.getElementById('confidenceText');
        const pillName = document.getElementById('pillName');
        const matchScore = document.getElementById('matchScore');
        const pillStatus = document.getElementById('pillStatus');
        const ledStatus = document.getElementById('ledStatus');
        const connDot = document.getElementById('connDot');
        const lastUpdate = document.getElementById('lastUpdate');
        const spectrumCard = document.getElementById('spectrumCard');
        
        // Initialize on load
        document.addEventListener('DOMContentLoaded', function() {
            initChart();
            testConnection();
            console.log('Mobile Scanner Ready - 11-channel version');
        });
        
        // Initialize Spectrum Chart
        function initChart() {
            const ctx = document.getElementById('spectrumChart');
            if (!ctx) return;
            
            chartInstance = new Chart(ctx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: WAVELENGTHS.map(w => `${w}nm`),
                    datasets: [{
                        label: 'Spectral Intensity',
                        data: [],
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true,
                        pointRadius: 3,
                        pointBackgroundColor: '#3498db'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Intensity'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Wavelength (nm)'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }
        
        // Update Spectrum Chart
        function updateSpectrumChart(spectrumValues) {
            if (!chartInstance) return;
            
            // Ensure we have 11 values (pad with zeros if needed)
            const paddedSpectrum = spectrumValues.slice(0, 11);
            while (paddedSpectrum.length < 11) {
                paddedSpectrum.push(0);
            }
            
            chartInstance.data.datasets[0].data = paddedSpectrum;
            chartInstance.update();
            
            // Show the spectrum card
            spectrumCard.style.display = 'block';
        }
        
        // Stream Functions
        function startStream() {
            if (isStreamActive) return;
            isStreamActive = true;
            
            const timestamp = new Date().getTime();
            liveStream.src = `http://${ESP_IP}/stream?t=${timestamp}&quality=15`;
            liveStream.style.display = 'block';
            streamPlaceholder.style.display = 'none';
            
            // Update FPS
            streamInterval = setInterval(() => {
                if (isStreamActive) {
                    const newTimestamp = new Date().getTime();
                    liveStream.src = `http://${ESP_IP}/stream?t=${newTimestamp}&quality=15`;
                }
            }, 200); // 5 FPS
            
            // Update UI
            document.querySelector('[onclick="startStream()"]').style.display = 'none';
            document.querySelector('[onclick="stopStream()"]').style.display = 'block';
        }
        
        function stopStream() {
            isStreamActive = false;
            clearInterval(streamInterval);
            streamInterval = null;
            
            liveStream.style.display = 'none';
            liveStream.src = '';
            streamPlaceholder.style.display = 'flex';
            
            // Update UI
            document.querySelector('[onclick="startStream()"]').style.display = 'block';
            document.querySelector('[onclick="stopStream()"]').style.display = 'none';
        }
        
        // Main Scan Function
        async function startScan() {
            if (!isStreamActive) {
                alert('Please start the stream first');
                return;
            }
            
            // Show loading
            scanSpinner.style.display = 'block';
            statusIcon.style.display = 'none';
            statusText.textContent = 'Scanning...';
            confidenceText.textContent = '';
            
            try {
                // Stop stream temporarily for scan
                stopStream();
                
                // Capture spectrum
                const espResponse = await fetch(`http://${ESP_IP}/capture_spectrum`);
                if (!espResponse.ok) throw new Error('ESP32 not responding');
                
                const espData = await espResponse.json();
                
                // Validate we have 11 channels
                const spectrumValues = espData.spectrum || espData.values || [];
                if (spectrumValues.length !== 11) {
                    console.warn(`Expected 11 channels, got ${spectrumValues.length}`);
                }
                
                // Update chart
                updateSpectrumChart(spectrumValues);
                
                // Send to server for analysis
                const phpResponse = await fetch(API_URL + 'scan.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        spectrum: spectrumValues,
                        wavelengths: espData.wavelengths || WAVELENGTHS,
                        esp_ip: ESP_IP,
                        channel_count: spectrumValues.length
                    })
                });
                
                const result = await phpResponse.json();
                
                // Update UI with results
                updateScanUI(result);
                
            } catch (error) {
                console.error('Scan failed:', error);
                statusIcon.textContent = '❌';
                statusIcon.style.display = 'block';
                statusText.textContent = 'Scan Failed';
                confidenceText.textContent = error.message;
            } finally {
                scanSpinner.style.display = 'none';
                statusIcon.style.display = 'block';
                
                // Restart stream
                setTimeout(() => {
                    if (!isStreamActive) startStream();
                }, 1000);
            }
        }
        
        function updateScanUI(result) {
            const status = result.status || 'UNKNOWN';
            const confidence = result.confidence || 0;
            const pill = result.pill_name || 'Unknown';
            const score = result.match_score || 0;
            
            // Update status icon and text
            switch(status) {
                case 'GENUINE':
                    statusIcon.textContent = '✅';
                    statusText.textContent = 'Genuine';
                    statusText.style.color = 'var(--success)';
                    break;
                case 'FAKE':
                    statusIcon.textContent = '❌';
                    statusText.textContent = 'Fake';
                    statusText.style.color = 'var(--danger)';
                    break;
                default:
                    statusIcon.textContent = '❓';
                    statusText.textContent = 'Unknown';
                    statusText.style.color = '#666';
            }
            
            // Update confidence
            if (confidence > 0) {
                confidenceText.textContent = `Confidence: ${(confidence * 100).toFixed(1)}%`;
            }
            
            // Update other results
            pillName.textContent = pill;
            matchScore.textContent = score > 0 ? `${(score * 100).toFixed(1)}%` : '-';
            pillStatus.textContent = status;
        }
        
        // Toggle LED
        async function toggleLED() {
            try {
                const response = await fetch(`http://${ESP_IP}/toggle_led`);
                const data = await response.json();
                
                ledStatus.textContent = data.led_on ? 'ON' : 'OFF';
                ledStatus.style.color = data.led_on ? 'var(--success)' : 'var(--danger)';
                
            } catch (error) {
                console.error('LED toggle failed:', error);
                alert('LED control failed');
            }
        }
        
        // Test Connection
        async function testConnection() {
            try {
                const response = await fetch(`http://${ESP_IP}/`, {
                    mode: 'no-cors',
                    cache: 'no-store'
                });
                
                updateConnectionStatus(true);
                
            } catch (error) {
                updateConnectionStatus(false);
            }
            
            // Update timestamp
            lastUpdate.textContent = new Date().toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
        }
        
        function updateConnectionStatus(isConnected) {
            if (isConnected) {
                connDot.className = 'status-dot online';
            } else {
                connDot.className = 'status-dot offline';
            }
        }
        
        // Handle visibility change (pause stream when app is in background)
        document.addEventListener('visibilitychange', function() {
            if (document.hidden && isStreamActive) {
                stopStream();
            }
        });
    </script>
</body>
</html>