<?php 
echo $_GET['ip'] ." >> .. OK";

 file_put_contents("ip.txt", $_GET['ip']);
?>