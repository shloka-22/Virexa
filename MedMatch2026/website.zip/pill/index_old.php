<?php
require_once "config.php"
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pill Authenticator System - Alfalah Suntech</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Keep all your CSS styles from previous version */
        :root {
            --primary: #3498db;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --dark: #2c3e50;
            --light: #ecf0f1;
        }
        
        /* ... (paste all your CSS styles here) ... */
        
        /* Server status indicator */
        .server-status {
            position: fixed;
            top: 10px;
            right: 10px;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
            z-index: 1000;
        }
        
        .server-online {
            background: var(--success);
            color: white;
        }
        
        .server-offline {
            background: var(--danger);
            color: white;
        }
    </style>
<script>
// Configuration for YOUR server
const ESP_IP = '<?php echo ESP32_IP; ?>';
const SERVER_BASE = '<?php echo SITE_URL; ?>';
const API_URL = SERVER_BASE + 'api/';

// Global variables
let chartInstance = null;
let tempSpectrumData = null;
let isScanning = false;


let streamInterval = null;
let isStreamActive = false;
let streamFps = 5; // Default FPS
let streamQuality = 'medium';



// ========== START SCAN FUNCTION ==========
async function startScan() {
    // Pause stream if active
    const wasStreaming = pauseStreamForOperation(5000); // Pause for 5 seconds for scan
    
    // Show loading
    document.getElementById('scanSpinner').style.display = 'block';
    document.getElementById('statusText').textContent = 'Scanning...';
    
    try {
        console.log('Step 1: Getting spectrum from ESP32...');
        
        // Get spectrum data from ESP32
        const espResponse = await fetch(`http://${ESP_IP}/capture_spectrum`);
        
        if (!espResponse.ok) {
            throw new Error(`ESP32 error: ${espResponse.status}`);
        }
        
        const espData = await espResponse.json();
        console.log('ESP32 spectrum:', espData.spectrum);
        
        // Optional: Get image separately
        console.log('Step 2: Getting image from ESP32...');
        let imageBase64 = null;
        try {
            const imageResponse = await fetch(`http://${ESP_IP}/capture`);
            if (imageResponse.ok) {
                const imageData = await imageResponse.json();
                imageBase64 = imageData.image;
            }
        } catch (imageError) {
            console.warn('Image capture failed, continuing without image:', imageError);
        }
        
        console.log('Step 3: Sending to PHP for analysis...');
        
        // Send to PHP server
        const phpResponse = await fetch(API_URL + 'scan.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                spectrum: espData.spectrum,
                wavelengths: espData.wavelengths || [415, 445, 480, 515, 555, 590, 630, 680],
                image: imageBase64,
                simulated: espData.simulated || false,
                esp_ip: ESP_IP
            })
        });
        
        const analysis = await phpResponse.json();
        console.log('PHP analysis:', analysis);
        
        // Update UI
        updateScanUI(analysis);
        
        // Update chart with actual spectrum
        updateSpectrumChart(espData.spectrum);
        
        // Show image if available
        if (imageBase64) {
           // document.getElementById('capturedImage').src = 
            //    'data:image/jpeg;base64,' + imageBase64;
        }
        
    } catch (error) {
        console.error('Scan failed:', error);
        document.getElementById('statusText').textContent = 'Scan Failed';
        document.getElementById('confidenceText').textContent = error.message;
        alert('Scan error: ' + error.message);
    } finally {
        document.getElementById('scanSpinner').style.display = 'none';
    }
}

// ========== TOGGLE LED FUNCTION ==========
async function toggleLED() {
    // Pause stream if active
    pauseStreamForOperation(1000);
    
    try {
        console.log('Toggling LED...');
        const response = await fetch(`http://${ESP_IP}/toggle_led`);
        const data = await response.json();
        
        // Update LED status in UI
        const ledStatus = document.getElementById('ledStatus');
        if (ledStatus) {
            ledStatus.textContent = data.led_on ? 'LED: ON' : 'LED: OFF';
            ledStatus.style.color = data.led_on ? '#2ecc71' : '#e74c3c';
        }
        
        console.log('LED toggled:', data);
        return data;
    } catch (error) {
        console.error('LED toggle failed:', error);
        alert('Failed to toggle LED: ' + error.message);
        return null;
    }
}

// ========== UPDATE SCAN UI FUNCTION ==========
function updateScanUI(result) {
    const status = result.status || 'UNKNOWN';
    const statusText = document.getElementById('statusText');
    const scanStatus = document.getElementById('scanStatus');
    const confidenceText = document.getElementById('confidenceText');
    
    if (!statusText || !scanStatus) return;
    
    // Update status display
    scanStatus.className = `status-content status-${status.toLowerCase()}`;
    
    switch(status) {
        case 'GENUINE':
            statusText.innerHTML = '✅ <strong>Pill is GENUINE</strong>';
            break;
        case 'FAKE':
            statusText.innerHTML = '❌ <strong>Pill is FAKE</strong>';
            break;
        case 'POSSIBLY_GENUINE':
            statusText.innerHTML = '⚠️ <strong>Possibly Genuine</strong>';
            break;
        default:
            statusText.innerHTML = '❓ <strong>Pill UNKNOWN</strong>';
    }
    
    // Update confidence
    if (confidenceText) {
        if (result.confidence) {
            confidenceText.textContent = `Confidence: ${(result.confidence * 100).toFixed(1)}%`;
        } else {
            confidenceText.textContent = '';
        }
    }
    
    // Update results panel
    if (result.pill_name) {
        const pillNameEl = document.getElementById('pillName');
        if (pillNameEl) pillNameEl.textContent = result.pill_name;
    }
    
    if (result.match_score) {
        const matchScoreEl = document.getElementById('matchScore');
        if (matchScoreEl) {
            matchScoreEl.textContent = `${(result.match_score * 100).toFixed(1)}%`;
        }
    }
    
    // Update status and time
    const pillStatusEl = document.getElementById('pillStatus');
    const scanTimeEl = document.getElementById('scanTime');
    
    if (pillStatusEl) pillStatusEl.textContent = status;
    if (scanTimeEl) scanTimeEl.textContent = new Date().toLocaleTimeString();
    
    console.log('Scan result displayed:', status);
}

// ========== UPDATE LIVE STREAM ==========
function updateLiveStream() {
    const liveStream = document.getElementById('liveStream');
    const timestamp = new Date().getTime();
    
    if (liveStream) {
        // Use cache-busting to prevent caching
        liveStream.src = `http://${ESP_IP}/stream?t=${timestamp}`;
        
        // Check if image loaded successfully
        liveStream.onload = function() {
            const streamError = document.getElementById('streamError');
            if (streamError) streamError.style.display = 'none';
            if (liveStream) liveStream.style.display = 'block';
        };
        
        liveStream.onerror = function() {
            if (liveStream) liveStream.style.display = 'none';
            const streamError = document.getElementById('streamError');
            if (streamError) streamError.style.display = 'block';
        };
    }
}

function showStreamError() {
    const liveStream = document.getElementById('liveStream');
    const streamError = document.getElementById('streamError');
    if (liveStream) liveStream.style.display = 'none';
    if (streamError) streamError.style.display = 'block';
}

function retryStream() {
    const streamError = document.getElementById('streamError');
    const liveStream = document.getElementById('liveStream');
    if (streamError) streamError.style.display = 'none';
    if (liveStream) liveStream.style.display = 'block';
    updateLiveStream();
}

// ========== INITIALIZE ON PAGE LOAD ==========
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing Pill Detection System...');
    
    // Initialize components
    initChart();
    loadPillDatabase();
    testConnection();
    //updateLiveStream();
    
    // Setup auto-refresh
    //setInterval(updateLiveStream, 1000);
    setInterval(testConnection, 30000); // Test every 30 seconds
    
    console.log('Initialization complete');
});

// ========== TEST CONNECTION ==========
async function testConnection() {
    try {
        console.log('Testing connection to ESP32...');
        const response = await fetch(`http://${ESP_IP}/`, {
            mode: 'no-cors',
            cache: 'no-store'
        });
        
        updateConnectionStatus(true);
        console.log('ESP32 connection: OK');
    } catch (error) {
        updateConnectionStatus(false);
        console.warn('ESP32 connection: FAILED', error);
    }
    
    // Update timestamp
    const lastUpdate = document.getElementById('lastUpdate');
    if (lastUpdate) {
        lastUpdate.textContent = new Date().toLocaleTimeString();
    }
}

function updateConnectionStatus(isConnected) {
    const statusElement = document.getElementById('espConnectionStatus');
    const serverStatus = document.getElementById('espStatus');
    
    if (statusElement) {
        if (isConnected) {
            statusElement.innerHTML = '<span style="color: #2ecc71;">✅ Connected</span>';
        } else {
            statusElement.innerHTML = '<span style="color: #e74c3c;">❌ Disconnected</span>';
        }
    }
    
    if (serverStatus) {
        if (isConnected) {
            serverStatus.innerHTML = 'ESP: ✅';
            serverStatus.className = 'server-status server-online';
        } else {
            serverStatus.innerHTML = 'ESP: ❌';
            serverStatus.className = 'server-status server-offline';
        }
    }
}

// ========== SPECTRUM CHART ==========
function initChart() {
    const ctx = document.getElementById('spectrumChart');
    if (!ctx) return;
    
    chartInstance = new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: ['415nm', '445nm', '480nm', '515nm', '555nm', '590nm', '630nm', '680nm'],
            datasets: [{
                label: 'Spectral Intensity',
                data: [],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                borderWidth: 3,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Intensity'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Wavelength'
                    }
                }
            }
        }
    });
    console.log('Chart initialized');
}

// ========== SAVE PILL MODAL FUNCTIONS ==========
function showSaveModal() {
    const saveModal = document.getElementById('saveModal');
    if (saveModal) saveModal.style.display = 'flex';
    
    // Clear previous data
    const pillNameInput = document.getElementById('pillNameInput');
    const manufacturerInput = document.getElementById('manufacturerInput');
    const expiryInput = document.getElementById('expiryInput');
    const notesInput = document.getElementById('notesInput');
    const captureStatus = document.getElementById('captureStatus');
    
    if (pillNameInput) pillNameInput.value = '';
    if (manufacturerInput) manufacturerInput.value = '';
    if (expiryInput) expiryInput.value = '';
    if (notesInput) notesInput.value = '';
    if (captureStatus) captureStatus.innerHTML = '';
    
    tempSpectrumData = null;
    console.log('Save modal opened');
}

function hideSaveModal() {
    const saveModal = document.getElementById('saveModal');
    if (saveModal) saveModal.style.display = 'none';
    console.log('Save modal closed');
}

// Display spectrum summary in modal
function displaySpectrumSummary(spectrumValues) {
    const summaryElement = document.getElementById('spectrumSummary');
    if (!summaryElement) {
        console.warn('spectrumSummary element not found');
        return;
    }
    
    if (!spectrumValues || !Array.isArray(spectrumValues) || spectrumValues.length === 0) {
        summaryElement.innerHTML = '<p>No spectrum data available</p>';
        return;
    }
    
    // Get wavelengths from tempSpectrumData or use defaults
    const wavelengths = (tempSpectrumData && tempSpectrumData.wavelengths) || 
                       [415, 445, 480, 515, 555, 590, 630, 680];
    
    let html = '<div class="spectrum-summary">';
    html += '<h4>📊 Spectrum Summary:</h4>';
    
    // Calculate statistics
    const max = Math.max(...spectrumValues).toFixed(1);
    const min = Math.min(...spectrumValues).toFixed(1);
    const sum = spectrumValues.reduce((a, b) => a + b, 0);
    const avg = (sum / spectrumValues.length).toFixed(1);
    
    html += '<div class="spectrum-stats">';
    html += `<p><strong>Data Points:</strong> ${spectrumValues.length}</p>`;
    html += `<p><strong>Max Intensity:</strong> ${max}</p>`;
    html += `<p><strong>Min Intensity:</strong> ${min}</p>`;
    html += `<p><strong>Average:</strong> ${avg}</p>`;
    html += `<p><strong>Total Intensity:</strong> ${sum.toFixed(1)}</p>`;
    html += '</div>';
    
    // Show individual channel values
    html += '<div class="channel-values">';
    html += '<h5>Channel Values:</h5>';
    
    spectrumValues.forEach((value, index) => {
        const wavelength = wavelengths[index] || `CH${index + 1}`;
        const percentage = ((value / 4095) * 100).toFixed(1); // Assuming 12-bit ADC
        
        html += `<div class="channel-row">
                    <span class="wavelength">${wavelength}nm</span>
                    <span class="value">${value.toFixed(1)}</span>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${percentage}%"></div>
                    </div>
                    <span class="percentage">${percentage}%</span>
                 </div>`;
    });
    
    html += '</div></div>';
    
    summaryElement.innerHTML = html;
    console.log('Spectrum summary displayed');
}
// ========== CAPTURE SPECTRUM SIGNATURE ==========
// ========== CAPTURE SPECTRUM SIGNATURE ==========
async function captureSignature() {
    // Pause stream if active
    pauseStreamForOperation(3000);
    
    const captureStatus = document.getElementById('captureStatus');
    if (!captureStatus) return;
    
    captureStatus.innerHTML = '<div class="alert alert-info">📸 Capturing spectrometer data...</div>';
    
    try {
        console.log('Capturing spectrum from ESP32...');
        
        // Call ESP32 spectrum endpoint
        const response = await fetch(`http://${ESP_IP}/capture_spectrum`);
        
        if (!response.ok) {
            throw new Error(`ESP32 error: ${response.status}`);
        }
        
        const spectrumData = await response.json();
        console.log('Spectrum captured:', spectrumData);
        
        const spectrumValues = spectrumData.values;
        
        if (!spectrumValues || !Array.isArray(spectrumValues)) {
            throw new Error('No valid spectrum data in response');
        }
        
        // Store for saving
        tempSpectrumData = {
            timestamp: new Date().toISOString(),
            raw: spectrumData,
            spectrum: spectrumValues,
            wavelengths: spectrumData.wavelengths,
            channels: spectrumData.channels,
            simulated: spectrumData.simulated,
            device: spectrumData.device
        };
        
        captureStatus.innerHTML = 
            '<div class="alert alert-success">✅ Spectrum captured successfully!<br>' +
            `<small>${spectrumValues.length} data points captured</small></div>`;
        
        updateSpectrumChart(spectrumValues);
        displaySpectrumSummary(spectrumValues);
        
    } catch (error) {
        console.error('Capture failed:', error);
        captureStatus.innerHTML = 
            '<div class="alert alert-error">❌ Failed to capture spectrum: ' + 
            error.message + '</div>';
    }
}

// ========== SAVE NEW PILL ==========
async function savePill() {
    if (!tempSpectrumData || !tempSpectrumData.spectrum) {
        alert('Please capture spectrum data first!');
        return;
    }
    
    const pillNameInput = document.getElementById('pillNameInput');
    if (!pillNameInput) return;
    
    const pillName = pillNameInput.value.trim();
    if (!pillName) {
        alert('Please enter pill name!');
        return;
    }
    
    console.log('Saving pill:', pillName);
    
    // Capture image as well
    const imageData = await captureCurrentImage();
    
    const pillData = {
        name: pillName,
        manufacturer: document.getElementById('manufacturerInput')?.value.trim() || '',
        expiry: document.getElementById('expiryInput')?.value || '',
        notes: document.getElementById('notesInput')?.value.trim() || '',
        spectrum: tempSpectrumData.spectrum,
        image_data: imageData,
        calibration: tempSpectrumData.calibration || {}
    };
    
    try {
        const response = await fetch(API_URL + 'save_pill.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(pillData)
        });
        
        const result = await response.json();
        console.log('Save response:', result);
        
        if (result.success) {
            alert(`✅ Pill "${pillName}" saved successfully!\nPill ID: ${result.pill_id}`);
            hideSaveModal();
            loadPillDatabase(); // Refresh list
        } else {
            alert('❌ Failed to save pill: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Save failed:', error);
        alert('❌ Error saving to database: ' + error.message);
    }
}

// ========== CAPTURE CURRENT IMAGE ==========
async function captureCurrentImage() {
    try {
        console.log('Capturing image from ESP32...');
        const response = await fetch(`http://${ESP_IP}/capture`);
        
        if (response.headers.get('content-type')?.includes('application/json')) {
            const data = await response.json();
            return data.image || null;
        } else {
            // ESP32 might return raw image
            const blob = await response.blob();
            return await blobToBase64(blob);
        }
    } catch (error) {
        console.warn('Image capture failed:', error);
        return null;
    }
}

// ========== LOAD PILL DATABASE ==========
async function loadPillDatabase() {
    try {
        console.log('Loading pill database...');
        const response = await fetch(API_URL + 'get_pills.php');
        const data = await response.json();
        
        if (data.success) {
            const pillCount = document.getElementById('pillCount');
            if (pillCount) pillCount.textContent = data.count;
            
            console.log(`Loaded ${data.count} pills from database`);
            
            // Update pill list
            const pillList = document.getElementById('pillList');
            if (pillList) {
                pillList.innerHTML = '';
                
                if (data.pills.length === 0) {
                    pillList.innerHTML = '<li>No pills in database yet</li>';
                } else {
                    data.pills.slice(0, 5).forEach(pill => {
                        const li = document.createElement('li');
                        li.className = 'pill-item';
                        li.innerHTML = `
                            <span><strong>${pill.name}</strong></span>
                            <small>${pill.manufacturer || 'Unknown'}</small>
                            <br><small style="color: #666;">${pill.created_at}</small>
                        `;
                        pillList.appendChild(li);
                    });
                }
            }
        }
    } catch (error) {
        console.error('Failed to load database:', error);
        const pillCount = document.getElementById('pillCount');
        if (pillCount) pillCount.textContent = 'Error';
    }
}

function refreshDatabase() {
    loadPillDatabase();
}

// ========== UPDATE SPECTRUM CHART ==========
// ========== UPDATE SPECTRUM CHART ==========
function updateSpectrumChart(spectrumValues) {
    console.log('Updating chart with:', spectrumValues);
    
    // Check if chart exists
    if (!chartInstance) {
        console.error('Chart not initialized!');
        return;
    }
    
    // Check if data is valid
    if (!spectrumValues || !Array.isArray(spectrumValues) || spectrumValues.length === 0) {
        console.error('Invalid spectrum data for chart:', spectrumValues);
        return;
    }
    
    // Update chart data
    chartInstance.data.datasets[0].data = spectrumValues;
    
    // Update X-axis labels with wavelengths if available
    if (tempSpectrumData && tempSpectrumData.wavelengths) {
        const wavelengths = tempSpectrumData.wavelengths;
        if (wavelengths.length === spectrumValues.length) {
            // Convert wavelengths to labels: "415nm", "445nm", etc.
            chartInstance.data.labels = wavelengths.map(w => `${w}nm`);
            console.log('Updated chart labels with wavelengths');
        }
    }
    
    // Update the chart
    chartInstance.update();
    console.log('Chart updated successfully!');
    
    // Show data in console for debugging
    console.log('Chart data points:', spectrumValues.length);
    console.log('Min value:', Math.min(...spectrumValues));
    console.log('Max value:', Math.max(...spectrumValues));
    console.log('Average:', (spectrumValues.reduce((a, b) => a + b, 0) / spectrumValues.length).toFixed(2));
}

// ========== HELPER FUNCTIONS ==========
function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

// ========== STREAM CONTROL FUNCTIONS ==========


function startStream() {
    const liveStream = document.getElementById('liveStream');
    const streamPlaceholder = document.getElementById('streamPlaceholder');
    const startBtn = document.getElementById('startStreamBtn');
    const stopBtn = document.getElementById('stopStreamBtn');
    const fpsSelect = document.getElementById('streamFps');
    const qualitySelect = document.getElementById('streamQuality');
    
    if (isStreamActive) return;
    isStreamActive = true;
    
    // Get current settings
    streamFps = parseInt(fpsSelect.value) || 5;
    streamQuality = qualitySelect.value || 'medium';
    
    const streamUrl = liveStream.getAttribute('data-stream-url');
    const delayMs = 1000 / streamFps; // Calculate delay between frames
    
    // Add quality parameter if ESP32 supports it
    let qualityParam = '';
    if (streamQuality === 'low') {
        qualityParam = '&quality=10';
    } else if (streamQuality === 'medium') {
        qualityParam = '&quality=15';
    } else if (streamQuality === 'high') {
        qualityParam = '&quality=20';
    }
    
    // Set initial stream source
    const timestamp = new Date().getTime();
    liveStream.src = `${streamUrl}?t=${timestamp}${qualityParam}`;
    liveStream.style.display = 'block';
    streamPlaceholder.style.display = 'none';
    
    // Show stop button, hide start button
    startBtn.style.display = 'none';
    stopBtn.style.display = 'inline-block';
    
    // Disable controls while streaming
    fpsSelect.disabled = true;
    qualitySelect.disabled = true;
    
    // Update image at the specified FPS
    streamInterval = setInterval(() => {
        if (isStreamActive) {
            const newTimestamp = new Date().getTime();
            liveStream.src = `${streamUrl}?t=${newTimestamp}${qualityParam}`;
        }
    }, delayMs);
    
    console.log(`Stream started at ${streamFps} FPS, quality: ${streamQuality}`);
}

function stopStream() {
    const liveStream = document.getElementById('liveStream');
    const streamPlaceholder = document.getElementById('streamPlaceholder');
    const startBtn = document.getElementById('startStreamBtn');
    const stopBtn = document.getElementById('stopStreamBtn');
    const fpsSelect = document.getElementById('streamFps');
    const qualitySelect = document.getElementById('streamQuality');
    
    isStreamActive = false;
    
    // Clear the interval
    if (streamInterval) {
        clearInterval(streamInterval);
        streamInterval = null;
    }
    
    // Hide stream, show placeholder
    liveStream.style.display = 'none';
    liveStream.src = ''; // Remove src to stop loading
    streamPlaceholder.style.display = 'flex';
    
    // Show start button, hide stop button
    startBtn.style.display = 'inline-block';
    stopBtn.style.display = 'none';
    
    // Re-enable controls
    fpsSelect.disabled = false;
    qualitySelect.disabled = false;
    
    console.log('Stream stopped');
}

// Pause stream temporarily for other operations
function pauseStreamForOperation(operationDuration = 2000) {
    if (!isStreamActive) return;
    
    console.log('Pausing stream for other operation...');
    
    // Stop the stream
    const wasStreamActive = isStreamActive;
    stopStream();
    
    // Resume after operation completes
    setTimeout(() => {
        if (wasStreamActive) {
            console.log('Resuming stream after operation');
            setTimeout(startStream, 500); // Small delay to ensure ESP32 is ready
        }
    }, operationDuration + 500);
    
    return wasStreamActive;
}


// Initialize stream controls when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const startBtn = document.getElementById('startStreamBtn');
    const stopBtn = document.getElementById('stopStreamBtn');
    
    if (startBtn) {
        startBtn.addEventListener('click', startStream);
    }
    if (stopBtn) {
        stopBtn.addEventListener('click', stopStream);
    }
    
    // Initialize stream as stopped
    stopStream();
});

</script>

    
</head>
<body>
    <!-- Server Status Indicator -->
    <div id="serverStatus" class="server-status">
        <span id="espStatus">ESP: ❓</span>
        <span id="serverConn" style="margin-left: 10px;">Server: ✅</span>
    </div>
    
    <div class="dashboard">
        <!-- Left: Camera & Spectrum -->
                <!-- Left: Camera & Spectrum -->
                <!-- Left: Camera & Spectrum -->
        <div class="camera-section">
    <h2 class="section-title">
        <i>📷</i> Live Camera Feed
    </h2>
    
    <!-- Stream Controls -->
    <div class="stream-controls" style="margin-bottom: 15px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
        <button id="startStreamBtn" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">
            <i>▶️</i> Start Live Stream
        </button>
        <button id="stopStreamBtn" style="padding: 10px 20px; background-color: #f44336; color: white; border: none; border-radius: 5px; cursor: pointer; display: none;">
            <i>⏸️</i> Stop Stream
        </button>
        
        <!-- Refresh Rate Control -->
        <div style="margin-left: 10px;">
            <label for="streamFps" style="color: white; margin-right: 5px;">FPS:</label>
            <select id="streamFps" style="padding: 5px; border-radius: 3px; background: #333; color: white; border: 1px solid #555;">
                <option value="1">1 FPS</option>
                <option value="2">2 FPS</option>
                <option value="5" selected>5 FPS</option>
                <option value="10">10 FPS</option>
                <option value="15">15 FPS</option>
            </select>
        </div>
        
        <!-- Quality Control -->
        <div>
            <label for="streamQuality" style="color: white; margin-right: 5px;">Quality:</label>
            <select id="streamQuality" style="padding: 5px; border-radius: 3px; background: #333; color: white; border: 1px solid #555;">
                <option value="low">Low</option>
                <option value="medium" selected>Medium</option>
                <option value="high">High</option>
            </select>
        </div>
    </div>
    
    <!-- Side-by-side container for camera and spectrum -->
    <div style="display: flex; gap: 20px; margin-bottom: 20px;">
        <!-- Left: Camera Stream -->
        <div style="flex: 1;">
            <!-- Live Stream Container -->
            <div style="background-color: #1a1a1a; border-radius: 8px; overflow: hidden; height: 400px; position: relative;">
                <!-- Live Stream from ESP32 -->
                <img id="liveStream" 
                     alt="Live Stream" 
                     style="display: none; width: 100%; height: 100%; object-fit: contain;"
                     data-stream-url="http://<?php echo ESP32_IP; ?>/stream">
                
                <!-- Stream Placeholder -->
                <div id="streamPlaceholder" style="width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #666;">
                    <div style="font-size: 48px; margin-bottom: 15px;">📷</div>
                    <p>Stream not started</p>
                </div>
            </div>
        </div>
        
        <!-- Right: Spectrum Chart -->
        <div style="flex: 1;">
            <div class="spectrum-chart" style="height: 400px;">
                <h3><i>📈</i> Spectral Signature</h3>
                <div style="height: 340px;">
                    <canvas id="spectrumChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
        
        <!-- In the control-buttons section -->
        <div class="control-buttons">
            <button class="btn btn-scan" onclick="startScan()" id="scanBtn">
                <i>🔍</i> Scan Pill
            </button>
            <button class="btn btn-save" onclick="showSaveModal()">
                <i>💾</i> Save New Pill
            </button>
            <button class="btn btn-led" onclick="toggleLED()">
                <i>💡</i> Toggle LED
            </button>
            <button class="btn" onclick="testConnection()" 
                    style="background: #9b59b6; color: white;">
                <i>🔌</i> Test Connection
            </button>
        </div>

        <!-- Add LED status display somewhere -->
        <div class="result-item">
            <strong>LED Status:</strong> <span id="ledStatus" style="color: #e74c3c;">OFF</span>
        </div>
            
            <!-- Connection Status -->
            <div class="status-panel">
                <h3 class="section-title">
                    <i>📡</i> Device Connection
                </h3>
                <div id="connectionStatus">
                    <p>ESP32 IP: <code id="espIp"><?php echo ESP32_IP; ?></code></p>
                    <p>Status: <span id="espConnectionStatus">Checking...</span></p>
                    <p>Last Update: <span id="lastUpdate">-</span></p>
                </div>
            </div>
            
            <!-- Scan Status -->
            <div class="status-panel">
                <h3 class="section-title">
                    <i>📊</i> Scan Status
                </h3>
                <div id="scanStatus" class="status-content status-idle">
                    <div class="spinner" id="scanSpinner"></div>
                    <div id="statusText">Ready to scan</div>
                    <div id="confidenceText" class="confidence"></div>
                </div>
            </div>
            
            <!-- Results Panel -->
            <div class="results-panel">
                <h3 class="section-title">
                    <i>📋</i> Scan Results
                </h3>
                <div id="results">
                    <div class="result-item">
                        <strong>Pill Name:</strong> <span id="pillName">-</span>
                    </div>
                    <div class="result-item">
                        <strong>Match Score:</strong> <span id="matchScore">-</span>
                    </div>
                    <div class="result-item">
                        <strong>Status:</strong> <span id="pillStatus">-</span>
                    </div>
                    <div class="result-item">
                        <strong>Time:</strong> <span id="scanTime">-</span>
                    </div>
                </div>
            </div>
            
            <!-- Database Panel -->
            <div class="database-panel">
                <h3 class="section-title">
                    <i>🗄️</i> Pill Database
                </h3>
                <div id="dbStats">
                    <p>Total Pills: <strong id="pillCount">0</strong></p>
                    <button class="btn-small" onclick="refreshDatabase()" 
                            style="background: #7f8c8d; color: white; padding: 5px 10px; font-size: 12px;">
                        Refresh
                    </button>
                    <h4>Recent Pills:</h4>
                    <ul class="pill-list" id="pillList">
                        <!-- Filled by JavaScript -->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Save New Pill Modal -->
    <div id="saveModal" class="modal">
        <div class="modal-content">
            <h2 style="margin-bottom: 20px;">
                <i>💊</i> Save New Pill Signature
            </h2>
            
            <form id="savePillForm">
                <div class="form-group">
                    <label for="pillName">Pill Name *</label>
                    <input type="text" id="pillNameInput" class="form-control" 
                           placeholder="e.g., Paracetamol 500mg" required>
                </div>
                
                <div class="form-group">
                    <label for="manufacturer">Manufacturer</label>
                    <input type="text" id="manufacturerInput" class="form-control" 
                           placeholder="e.g., PharmaCorp Inc.">
                </div>
                
                <div class="form-group">
                    <label for="expiry">Expiry Date</label>
                    <input type="date" id="expiryInput" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="notes">Notes</label>
                    <textarea id="notesInput" class="form-control" rows="3" 
                              placeholder="Additional information..."></textarea>
                </div>
                
                <div id="captureStatus" class="form-group" style="text-align: center;"></div>
                
                <div class="modal-buttons">
                    <button type="button" class="btn" onclick="captureSignature()" 
                            style="background: var(--primary); color: white;">
                        <i>📸</i> Capture Signature
                    </button>
                    <button type="button" class="btn btn-save" onclick="savePill()">
                        <i>💾</i> Save to Database
                    </button>
                    <button type="button" class="btn" onclick="hideSaveModal()" 
                            style="background: var(--danger); color: white;">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Include JavaScript -->
    
</body>
</html>