// Configuration for YOUR server
const ESP_IP = '<?php echo ESP32_IP; ?>';
const SERVER_BASE = '<?php echo SITE_URL; ?>';
const API_URL = SERVER_BASE + 'api/';

// Global variables
let chartInstance = null;
let tempSpectrumData = null;
let isScanning = false;

// ========== START SCAN FUNCTION ==========
async function startScan() {
    if (isScanning) {
        alert('Scan already in progress!');
        return;
    }
    
    isScanning = true;
    const scanBtn = document.getElementById('scanBtn');
    if (scanBtn) scanBtn.disabled = true;
    
    // Show scanning state
    const scanSpinner = document.getElementById('scanSpinner');
    const statusText = document.getElementById('statusText');
    const scanStatus = document.getElementById('scanStatus');
    
    if (scanSpinner) scanSpinner.style.display = 'block';
    if (statusText) statusText.textContent = 'Scanning... Please wait';
    if (scanStatus) scanStatus.className = 'status-content status-scanning';
    
    try {
        console.log('Starting scan...');
        
        // Create form data
        const formData = new FormData();
        formData.append('esp_ip', ESP_IP);
        
        // Call scan API
        const response = await fetch(API_URL + 'scan.php', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('Scan result:', result);
        
        // Update UI with results
        updateScanUI(result);
        
        // Update chart if spectral data available
        if (result.spectral_data) {
            updateSpectrumChart(result.spectral_data);
        }
        
    } catch (error) {
        console.error('Scan failed:', error);
        
        // Update UI with error
        if (statusText) statusText.textContent = 'Scan Failed';
        if (confidenceText) {
            document.getElementById('confidenceText').textContent = 
                'Error: ' + (error.message || 'Connection failed');
        }
        if (scanStatus) scanStatus.className = 'status-content status-unknown';
        
        alert('Scan failed: ' + error.message);
    } finally {
        if (scanSpinner) scanSpinner.style.display = 'none';
        if (scanBtn) scanBtn.disabled = false;
        isScanning = false;
    }
}

// ========== TOGGLE LED FUNCTION ==========
async function toggleLED() {
    try {
        console.log('Toggling LED...');
        const response = await fetch(`http://${ESP_IP}/toggle_led`);
        const data = await response.json();
        
        // Update LED status in UI
        const ledStatus = document.getElementById('ledStatus');
        if (ledStatus) {
            ledStatus.textContent = data.led_on ? 'LED: ON' : 'LED: OFF';
            ledStatus.style.color = data.led_on ? '#2ecc71' : '#e74c3c';
        }
        
        console.log('LED toggled:', data);
        return data;
    } catch (error) {
        console.error('LED toggle failed:', error);
        alert('Failed to toggle LED: ' + error.message);
        return null;
    }
}

// ========== UPDATE SCAN UI FUNCTION ==========
function updateScanUI(result) {
    const status = result.status || 'UNKNOWN';
    const statusText = document.getElementById('statusText');
    const scanStatus = document.getElementById('scanStatus');
    const confidenceText = document.getElementById('confidenceText');
    
    if (!statusText || !scanStatus) return;
    
    // Update status display
    scanStatus.className = `status-content status-${status.toLowerCase()}`;
    
    switch(status) {
        case 'GENUINE':
            statusText.innerHTML = '✅ <strong>Pill is GENUINE</strong>';
            break;
        case 'FAKE':
            statusText.innerHTML = '❌ <strong>Pill is FAKE</strong>';
            break;
        case 'POSSIBLY_GENUINE':
            statusText.innerHTML = '⚠️ <strong>Possibly Genuine</strong>';
            break;
        default:
            statusText.innerHTML = '❓ <strong>Pill UNKNOWN</strong>';
    }
    
    // Update confidence
    if (confidenceText) {
        if (result.confidence) {
            confidenceText.textContent = `Confidence: ${(result.confidence * 100).toFixed(1)}%`;
        } else {
            confidenceText.textContent = '';
        }
    }
    
    // Update results panel
    if (result.pill_name) {
        const pillNameEl = document.getElementById('pillName');
        if (pillNameEl) pillNameEl.textContent = result.pill_name;
    }
    
    if (result.match_score) {
        const matchScoreEl = document.getElementById('matchScore');
        if (matchScoreEl) {
            matchScoreEl.textContent = `${(result.match_score * 100).toFixed(1)}%`;
        }
    }
    
    // Update status and time
    const pillStatusEl = document.getElementById('pillStatus');
    const scanTimeEl = document.getElementById('scanTime');
    
    if (pillStatusEl) pillStatusEl.textContent = status;
    if (scanTimeEl) scanTimeEl.textContent = new Date().toLocaleTimeString();
    
    console.log('Scan result displayed:', status);
}

// ========== UPDATE LIVE STREAM ==========
function updateLiveStream() {
    const liveStream = document.getElementById('liveStream');
    const timestamp = new Date().getTime();
    
    if (liveStream) {
        // Use cache-busting to prevent caching
        liveStream.src = `http://${ESP_IP}/stream?t=${timestamp}`;
        
        // Check if image loaded successfully
        liveStream.onload = function() {
            const streamError = document.getElementById('streamError');
            if (streamError) streamError.style.display = 'none';
            if (liveStream) liveStream.style.display = 'block';
        };
        
        liveStream.onerror = function() {
            if (liveStream) liveStream.style.display = 'none';
            const streamError = document.getElementById('streamError');
            if (streamError) streamError.style.display = 'block';
        };
    }
}

function showStreamError() {
    const liveStream = document.getElementById('liveStream');
    const streamError = document.getElementById('streamError');
    if (liveStream) liveStream.style.display = 'none';
    if (streamError) streamError.style.display = 'block';
}

function retryStream() {
    const streamError = document.getElementById('streamError');
    const liveStream = document.getElementById('liveStream');
    if (streamError) streamError.style.display = 'none';
    if (liveStream) liveStream.style.display = 'block';
    updateLiveStream();
}

// ========== INITIALIZE ON PAGE LOAD ==========
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing Pill Detection System...');
    
    // Initialize components
    initChart();
    loadPillDatabase();
    testConnection();
    updateLiveStream();
    
    // Setup auto-refresh
    setInterval(updateLiveStream, 1000);
    setInterval(testConnection, 30000); // Test every 30 seconds
    
    console.log('Initialization complete');
});

// ========== TEST CONNECTION ==========
async function testConnection() {
    try {
        console.log('Testing connection to ESP32...');
        const response = await fetch(`http://${ESP_IP}/`, {
            mode: 'no-cors',
            cache: 'no-store'
        });
        
        updateConnectionStatus(true);
        console.log('ESP32 connection: OK');
    } catch (error) {
        updateConnectionStatus(false);
        console.warn('ESP32 connection: FAILED', error);
    }
    
    // Update timestamp
    const lastUpdate = document.getElementById('lastUpdate');
    if (lastUpdate) {
        lastUpdate.textContent = new Date().toLocaleTimeString();
    }
}

function updateConnectionStatus(isConnected) {
    const statusElement = document.getElementById('espConnectionStatus');
    const serverStatus = document.getElementById('espStatus');
    
    if (statusElement) {
        if (isConnected) {
            statusElement.innerHTML = '<span style="color: #2ecc71;">✅ Connected</span>';
        } else {
            statusElement.innerHTML = '<span style="color: #e74c3c;">❌ Disconnected</span>';
        }
    }
    
    if (serverStatus) {
        if (isConnected) {
            serverStatus.innerHTML = 'ESP: ✅';
            serverStatus.className = 'server-status server-online';
        } else {
            serverStatus.innerHTML = 'ESP: ❌';
            serverStatus.className = 'server-status server-offline';
        }
    }
}

// ========== SPECTRUM CHART ==========
function initChart() {
    const ctx = document.getElementById('spectrumChart');
    if (!ctx) return;
    
    chartInstance = new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: ['415nm', '445nm', '480nm', '515nm', '555nm', '590nm', '630nm', '680nm'],
            datasets: [{
                label: 'Spectral Intensity',
                data: [],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                borderWidth: 3,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Intensity'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Wavelength'
                    }
                }
            }
        }
    });
    console.log('Chart initialized');
}

// ========== SAVE PILL MODAL FUNCTIONS ==========
function showSaveModal() {
    const saveModal = document.getElementById('saveModal');
    if (saveModal) saveModal.style.display = 'flex';
    
    // Clear previous data
    const pillNameInput = document.getElementById('pillNameInput');
    const manufacturerInput = document.getElementById('manufacturerInput');
    const expiryInput = document.getElementById('expiryInput');
    const notesInput = document.getElementById('notesInput');
    const captureStatus = document.getElementById('captureStatus');
    
    if (pillNameInput) pillNameInput.value = '';
    if (manufacturerInput) manufacturerInput.value = '';
    if (expiryInput) expiryInput.value = '';
    if (notesInput) notesInput.value = '';
    if (captureStatus) captureStatus.innerHTML = '';
    
    tempSpectrumData = null;
    console.log('Save modal opened');
}

function hideSaveModal() {
    const saveModal = document.getElementById('saveModal');
    if (saveModal) saveModal.style.display = 'none';
    console.log('Save modal closed');
}

// ========== CAPTURE SPECTRUM SIGNATURE ==========
async function captureSignature() {
    const captureStatus = document.getElementById('captureStatus');
    if (!captureStatus) return;
    
    captureStatus.innerHTML = '<div class="alert alert-info">Capturing spectrometer data...</div>';
    
    try {
        console.log('Capturing spectrum from ESP32...');
        
        // Call ESP32 spectrum endpoint
        const response = await fetch(`http://${ESP_IP}/capture_spectrum`);
        
        if (!response.ok) {
            throw new Error(`ESP32 error: ${response.status}`);
        }
        
        const spectrumData = await response.json();
        console.log('Spectrum captured:', spectrumData);
        
        // Store for saving
        tempSpectrumData = spectrumData;
        
        captureStatus.innerHTML = 
            '<div class="alert alert-success">✅ Spectrum captured successfully!</div>';
        
        // Update chart with captured spectrum
        if (spectrumData.spectrum) {
            updateSpectrumChart(spectrumData.spectrum);
        }
        
    } catch (error) {
        console.error('Capture failed:', error);
        captureStatus.innerHTML = 
            '<div class="alert alert-error">❌ Failed to capture spectrum: ' + 
            error.message + '</div>';
    }
}

// ========== SAVE NEW PILL ==========
async function savePill() {
    if (!tempSpectrumData || !tempSpectrumData.spectrum) {
        alert('Please capture spectrum data first!');
        return;
    }
    
    const pillNameInput = document.getElementById('pillNameInput');
    if (!pillNameInput) return;
    
    const pillName = pillNameInput.value.trim();
    if (!pillName) {
        alert('Please enter pill name!');
        return;
    }
    
    console.log('Saving pill:', pillName);
    
    // Capture image as well
    const imageData = await captureCurrentImage();
    
    const pillData = {
        name: pillName,
        manufacturer: document.getElementById('manufacturerInput')?.value.trim() || '',
        expiry: document.getElementById('expiryInput')?.value || '',
        notes: document.getElementById('notesInput')?.value.trim() || '',
        spectrum: tempSpectrumData.spectrum,
        image_data: imageData,
        calibration: tempSpectrumData.calibration || {}
    };
    
    try {
        const response = await fetch(API_URL + 'save_pill.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(pillData)
        });
        
        const result = await response.json();
        console.log('Save response:', result);
        
        if (result.success) {
            alert(`✅ Pill "${pillName}" saved successfully!\nPill ID: ${result.pill_id}`);
            hideSaveModal();
            loadPillDatabase(); // Refresh list
        } else {
            alert('❌ Failed to save pill: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Save failed:', error);
        alert('❌ Error saving to database: ' + error.message);
    }
}

// ========== CAPTURE CURRENT IMAGE ==========
async function captureCurrentImage() {
    try {
        console.log('Capturing image from ESP32...');
        const response = await fetch(`http://${ESP_IP}/capture`);
        
        if (response.headers.get('content-type')?.includes('application/json')) {
            const data = await response.json();
            return data.image || null;
        } else {
            // ESP32 might return raw image
            const blob = await response.blob();
            return await blobToBase64(blob);
        }
    } catch (error) {
        console.warn('Image capture failed:', error);
        return null;
    }
}

// ========== LOAD PILL DATABASE ==========
async function loadPillDatabase() {
    try {
        console.log('Loading pill database...');
        const response = await fetch(API_URL + 'get_pills.php');
        const data = await response.json();
        
        if (data.success) {
            const pillCount = document.getElementById('pillCount');
            if (pillCount) pillCount.textContent = data.count;
            
            console.log(`Loaded ${data.count} pills from database`);
            
            // Update pill list
            const pillList = document.getElementById('pillList');
            if (pillList) {
                pillList.innerHTML = '';
                
                if (data.pills.length === 0) {
                    pillList.innerHTML = '<li>No pills in database yet</li>';
                } else {
                    data.pills.slice(0, 5).forEach(pill => {
                        const li = document.createElement('li');
                        li.className = 'pill-item';
                        li.innerHTML = `
                            <span><strong>${pill.name}</strong></span>
                            <small>${pill.manufacturer || 'Unknown'}</small>
                            <br><small style="color: #666;">${pill.created_at}</small>
                        `;
                        pillList.appendChild(li);
                    });
                }
            }
        }
    } catch (error) {
        console.error('Failed to load database:', error);
        const pillCount = document.getElementById('pillCount');
        if (pillCount) pillCount.textContent = 'Error';
    }
}

function refreshDatabase() {
    loadPillDatabase();
}

// ========== UPDATE SPECTRUM CHART ==========
function updateSpectrumChart(spectrumData) {
    if (chartInstance && spectrumData && Array.isArray(spectrumData)) {
        chartInstance.data.datasets[0].data = spectrumData;
        chartInstance.update();
        console.log('Chart updated with spectrum data');
    }
}

// ========== HELPER FUNCTIONS ==========
function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}