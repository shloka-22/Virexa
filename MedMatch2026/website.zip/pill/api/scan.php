<?php
// api/scan.php
require_once '../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from JavaScript (which got it from ESP32)
    $input = json_decode(file_get_contents('php://input'), true);
    
    $spectrum = $input['spectrum'] ?? [];
    $wavelengths = $input['wavelengths'] ?? [];
    $image_data = $input['image'] ?? null;
    
    // Analyze the spectrum against database
    $result = analyzeSpectrum($spectrum);
    
    // Add spectrum data for chart
    $result['spectrum'] = $spectrum;
    $result['wavelengths'] = $wavelengths;
    
    echo json_encode($result);
}

function analyzeSpectrum($spectrum) {
    // Load database
    $db = json_decode(file_get_contents(PILLS_DB), true);
    $pills = $db['pills'] ?? [];
    
    if (empty($pills)) {
        return [
            'status' => 'UNKNOWN',
            'confidence' => 0,
            'message' => 'No reference pills in database'
        ];
    }
    
    $best_match = null;
    $best_score = 0;
    
    foreach ($pills as $pill) {
        $ref_spectrum = $pill['spectrum'] ?? [];
        $score = calculateSimilarity($spectrum, $ref_spectrum);
        
        if ($score > $best_score) {
            $best_score = $score;
            $best_match = $pill;
        }
    }
    
    // Determine result
    if ($best_score > 0.9) {
        return [
            'status' => 'GENUINE',
            'confidence' => $best_score,
            'pill_name' => $best_match['name'] ?? 'Unknown',
            'match_score' => $best_score
        ];
    } elseif ($best_score > 0.8) {
        return [
            'status' => 'POSSIBLY_GENUINE',
            'confidence' => $best_score,
            'pill_name' => $best_match['name'] ?? 'Unknown'
        ];
    } else {
        return [
            'status' => 'FAKE',
            'confidence' => 1 - $best_score
        ];
    }
}
function calculateSimilarity($arr1, $arr2, $weightPower = 1.0) {
    if (count($arr1) !== count($arr2)) return 0;
    
    $n = count($arr1);
    $weightedSum = 0;
    $totalWeight = 0;
    
    // Find data range for normalization
    $combined = array_merge($arr1, $arr2);
    $data_max = max($combined);
    
    for ($i = 0; $i < $n; $i++) {
        // Weight increases with position (adjust formula as needed)
        $weight = pow(($i + 1) / $n, $weightPower);
        
        $diff = $arr1[$i] - $arr2[$i];
        $weightedSum += $weight * $diff * $diff;
        $totalWeight += $weight;
    }
    
    $distance = sqrt($weightedSum);
    $max_possible = sqrt($totalWeight * $data_max * $data_max);
    
    return max(0, 1 - ($distance / $max_possible));
}
?>