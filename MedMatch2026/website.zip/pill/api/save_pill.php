<?php
require_once '../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (empty($input['name']) || empty($input['spectrum'])) {
        echo json_encode(['error' => 'Missing required fields']);
        exit;
    }
    
    // Generate unique ID
    $pill_id = uniqid('pill_', true);
    
    // Save image if provided
    $image_path = null;
    if (!empty($input['image_data'])) {
        $image_path = savePillImage($input['image_data'], $pill_id);
    }
    
    // Create pill record
    $pill_record = [
        'id' => $pill_id,
        'name' => $input['name'],
        'manufacturer' => $input['manufacturer'] ?? '',
        'expiry' => $input['expiry'] ?? '',
        'notes' => $input['notes'] ?? '',
        'spectrum' => $input['spectrum'],
        'image_path' => $image_path,
        'created_at' => date('Y-m-d H:i:s'),
        'calibration' => $input['calibration'] ?? []
    ];
    
    // Save to database
    $db = json_decode(file_get_contents(PILLS_DB), true);
    $db['pills'][] = $pill_record;
    
    if (file_put_contents(PILLS_DB, json_encode($db, JSON_PRETTY_PRINT))) {
        echo json_encode([
            'success' => true,
            'message' => "Pill '{$input['name']}' saved successfully",
            'pill_id' => $pill_id,
            'total_pills' => count($db['pills'])
        ]);
    } else {
        echo json_encode(['error' => 'Failed to save to database']);
    }
}

function savePillImage($base64_image, $pill_id) {
    // Remove data URL prefix if present
    if (strpos($base64_image, 'base64,') !== false) {
        $base64_image = explode('base64,', $base64_image)[1];
    }
    
    $image_data = base64_decode($base64_image);
    $filename = $pill_id . '_' . time() . '.jpg';
    $filepath = UPLOAD_DIR . $filename;
    
    if (file_put_contents($filepath, $image_data)) {
        return $filename;
    }
    
    return null;
}
?>