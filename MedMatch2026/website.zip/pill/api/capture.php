<?php
require_once '../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $type = $_GET['type'] ?? 'all'; // 'image', 'spectrum', or 'all'
    $esp_ip = $_GET['esp_ip'] ?? ESP32_IP;
    
    $result = [];
    
    if ($type === 'image' || $type === 'all') {
        $image = captureImage($esp_ip);
        if ($image) $result['image'] = $image;
    }
    
    if ($type === 'spectrum' || $type === 'all') {
        $spectrum = captureSpectrum($esp_ip);
        if ($spectrum) $result['spectrum'] = $spectrum;
    }
    
    echo json_encode($result);
}

function captureImage($ip) {
    $url = "http://{$ip}/capture";
    return fetchFromESP32($url);
}

function captureSpectrum($ip) {
    $url = "http://{$ip}/capture_spectrum";
    $data = fetchFromESP32($url);
    return json_decode($data, true);
}

function fetchFromESP32($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}
?>