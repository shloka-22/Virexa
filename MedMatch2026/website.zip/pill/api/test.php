<?php
// test.php - Enhanced debug version
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Testing ESP32 Connection</h2>";

$url = "http://192.168.10.4/toggle_led";
echo "URL: $url<br><br>";

// Method 1: file_get_contents (simpler)
echo "<h3>Method 1: file_get_contents</h3>";
$start = microtime(true);
$context = stream_context_create([
    'http' => [
        'timeout' => 5,
        'ignore_errors' => true,
        'header' => "User-Agent: PHP Test Script\r\n"
    ]
]);

$response1 = @file_get_contents($url, false, $context);
$time1 = round(microtime(true) - $start, 3);

if ($response1 === FALSE) {
    echo "❌ FAILED in {$time1}s<br>";
    $error = error_get_last();
    echo "Error: " . htmlspecialchars($error['message']) . "<br>";
} else {
    echo "✅ SUCCESS in {$time1}s<br>";
    echo "Response length: " . strlen($response1) . " bytes<br>";
    
    // Try to decode JSON
    $data = json_decode($response1, true);
    if ($data) {
        echo "Valid JSON!<br>";
        echo "Status: " . ($data['status'] ?? 'N/A') . "<br>";
        if (isset($data['spectrum'])) {
            echo "Spectrum: " . implode(', ', $data['spectrum']) . "<br>";
        }
    } else {
        echo "Invalid JSON. First 200 chars:<br>";
        echo "<pre>" . htmlspecialchars(substr($response1, 0, 200)) . "</pre>";
    }
}

echo "<hr>";

// Method 2: cURL with detailed debug
echo "<h3>Method 2: cURL with Detailed Debug</h3>";

if (!function_exists('curl_init')) {
    echo "❌ cURL not installed!<br>";
} else {
    $ch = curl_init($url);
    
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_USERAGENT => 'PHP-cURL-Test',
        
        // Enable verbose output to a file
        CURLOPT_VERBOSE => true,
        CURLOPT_STDERR => $verbose = fopen('php://temp', 'w+'),
        
        // Get connection info
        CURLOPT_NOPROGRESS => false,
        CURLOPT_PROGRESSFUNCTION => function($resource, $download_size, $downloaded, $upload_size, $uploaded) {
            static $last_log = 0;
            if (microtime(true) - $last_log > 0.5) {
                $last_log = microtime(true);
                echo "cURL Progress: $downloaded / " . ($download_size ?: 'unknown') . " bytes<br>";
                flush();
            }
            return 0;
        }
    ]);
    
    echo "Starting cURL request...<br>";
    flush();
    
    $start = microtime(true);
    $response = curl_exec($ch);
    $time_taken = round(microtime(true) - $start, 3);
    
    echo "cURL completed in {$time_taken}s<br>";
    
    if (curl_errno($ch)) {
        echo "❌ cURL ERROR: " . curl_error($ch) . " (Code: " . curl_errno($ch) . ")<br>";
        
        // Get verbose output
        rewind($verbose);
        $verbose_log = stream_get_contents($verbose);
        fclose($verbose);
        
        echo "<h4>cURL Verbose Log:</h4>";
        echo "<pre>" . htmlspecialchars($verbose_log) . "</pre>";
        
    } else {
        echo "✅ cURL executed without errors<br>";
        
        // Get info
        $info = curl_getinfo($ch);
        echo "HTTP Code: " . $info['http_code'] . "<br>";
        echo "Total Time: " . $info['total_time'] . "s<br>";
        echo "Connect Time: " . $info['connect_time'] . "s<br>";
        echo "Name Lookup Time: " . $info['namelookup_time'] . "s<br>";
        echo "Download Size: " . $info['size_download'] . " bytes<br>";
        echo "Speed: " . round($info['speed_download'] / 1024, 2) . " KB/s<br>";
        
        // Separate headers from body
        $header_size = $info['header_size'];
        $headers = substr($response, 0, $header_size);
        $body = substr($response, $header_size);
        
        echo "<h4>Response Headers:</h4>";
        echo "<pre>" . htmlspecialchars($headers) . "</pre>";
        
        echo "<h4>Response Body (first 500 chars):</h4>";
        echo "<pre>" . htmlspecialchars(substr($body, 0, 500)) . "</pre>";
        
        // Try to parse JSON
        $data = json_decode($body, true);
        if ($data) {
            echo "<h4>Parsed JSON:</h4>";
            echo "<pre>";
            print_r($data);
            echo "</pre>";
        }
        
        // Get verbose output even on success
        rewind($verbose);
        $verbose_log = stream_get_contents($verbose);
        fclose($verbose);
        
        echo "<h4>cURL Verbose Log:</h4>";
        echo "<pre>" . htmlspecialchars($verbose_log) . "</pre>";
    }
    
    curl_close($ch);
}

echo "<hr>";

// Method 3: Test network connectivity
echo "<h3>Method 3: Network Diagnostics</h3>";

echo "Server IP: " . ($_SERVER['SERVER_ADDR'] ?? 'Unknown') . "<br>";
echo "Server Hostname: " . gethostname() . "<br>";
echo "PHP Version: " . PHP_VERSION . "<br>";
echo "allow_url_fopen: " . (ini_get('allow_url_fopen') ? 'ON' : 'OFF') . "<br>";

// Simple socket test
echo "<h4>Socket Connection Test:</h4>";
$fp = @fsockopen('192.168.10.4', 80, $errno, $errstr, 5);
if ($fp) {
    echo "✅ Socket connection successful<br>";
    
    // Send HTTP request manually
    $out = "GET /capture_spectrum HTTP/1.1\r\n";
    $out .= "Host: 192.168.10.4\r\n";
    $out .= "Connection: Close\r\n\r\n";
    
    fwrite($fp, $out);
    
    $socket_response = '';
    while (!feof($fp)) {
        $socket_response .= fgets($fp, 128);
    }
    fclose($fp);
    
    echo "Socket response (first 300 chars):<br>";
    echo "<pre>" . htmlspecialchars(substr($socket_response, 0, 300)) . "</pre>";
} else {
    echo "❌ Socket connection failed: $errstr ($errno)<br>";
}

// Test if ESP32 is reachable via ping (if allowed)
echo "<h4>Ping Test (if available):</h4>";
$output = [];
$return = 0;
@exec("ping -c 2 -W 2 192.168.10.4 2>&1", $output, $return);
if ($return == 0) {
    echo "✅ ESP32 is reachable via ping<br>";
} else {
    echo "❌ ESP32 is NOT reachable via ping<br>";
}
echo "<pre>" . implode("\n", $output) . "</pre>";

echo "<hr>";
echo "<h3>PHP Configuration:</h3>";
echo "<pre>";
print_r([
    'curl_version' => function_exists('curl_version') ? curl_version() : 'Not available',
    'open_basedir' => ini_get('open_basedir'),
    'disable_functions' => ini_get('disable_functions'),
    'memory_limit' => ini_get('memory_limit'),
    'max_execution_time' => ini_get('max_execution_time')
]);
echo "</pre>";
?>