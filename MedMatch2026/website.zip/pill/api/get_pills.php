<?php
require_once '../config.php';

header('Content-Type: application/json');

$db = json_decode(file_get_contents(PILLS_DB), true);

// Return only essential data (not full spectrum for list)
$pills_list = array_map(function($pill) {
    return [
        'id' => $pill['id'],
        'name' => $pill['name'],
        'manufacturer' => $pill['manufacturer'],
        'created_at' => $pill['created_at'],
        'has_image' => !empty($pill['image_path'])
    ];
}, $db['pills'] ?? []);

echo json_encode([
    'success' => true,
    'count' => count($pills_list),
    'pills' => array_reverse($pills_list) // Newest first
]);
?>